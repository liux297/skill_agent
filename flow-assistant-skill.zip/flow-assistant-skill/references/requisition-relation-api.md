# 📄 项目单据/申请单查询 API 使用规范

## API 端点

```
GET http://10.0.21.38:8080/dy/flowable/instance/getRequisitionRelation?instanceId={instanceId}&time={timestamp}
⚠️ 此接口仅支持 GET 方法（已实测验证 2026-06-10，参数通过 URL query string 传递）
```

## 请求参数

| 参数名 | 类型 | 必填 | 说明 | 示例值 |
|--------|------|------|------|--------|
| instanceId | string | 是 | 流程实例 ID（来自项目列表接口返回的 `instanceId` 字段） | "26612501" |
| time | string | 否 | 当前时间戳（毫秒），用于防止缓存，可用 $(date +%s%3N) 生成 | 1749600000000 |

## 请求头

| 参数 | 值 | 必填 | 说明 |
|------|-----|------|------|
| iv-user | <user-id> | 是 | 用户工号（如 dstest） |
| systemcode | AGENT | 是 | 系统编码 |
| Accept | */* | 是 | 接受任意内容类型 |

## 调用示例

### 基础调用

```bash
curl -s 'http://10.0.21.38:8080/dy/flowable/instance/getRequisitionRelation?instanceId=26612501&time='$(date +%s%3N)'' \
  -H 'iv-user: dstest' \
  -H 'systemcode: AGENT' \
  -H 'Accept: */*' \
  --insecure
```

### 使用 jq 格式化输出

```bash
curl -s 'http://10.0.21.38:8080/dy/flowable/instance/getRequisitionRelation?instanceId=26612501&time='$(date +%s%3N)'' \
  -H 'iv-user: dstest' \
  -H 'systemcode: AGENT' \
  -H 'Accept: */*' \
  --insecure | jq '.'
```

### 不带 time 参数调用

```bash
curl -s 'http://10.0.21.38:8080/dy/flowable/instance/getRequisitionRelation?instanceId=26612501' \
  -H 'iv-user: dstest' \
  -H 'systemcode: AGENT' \
  -H 'Accept: */*' \
  --insecure
```

## 返回结构

### ⚠️ 重要：返回数据为树形结构（非扁平数组）

该接口返回的数据是**树形结构**，顶层节点通常只有 **1 条**（商机录入/根节点），**实际的业务单据（合同、订单、采购等）都在 `children` 节点中**。解析时必须递归遍历 `children` 才能获取完整单据列表。

### 数据层级示意

```
data (数组)
├── [0] 根节点（如：商机录入）          ← 顶层通常仅 1 条
│   ├── serialNumber: P202604454442    ← 商机编号
│   ├── nodeName: 商机录入
│   └── children (子单据数组)           ← ★ 真正的业务单据在这里
│       ├── [0] 合同申请               ← 子节点也有完整字段
│       │   ├── serialNumber: HT202605130001
│       │   └── children (孙单据)      ← 可继续嵌套
│       │       ├── [0] 生成订单        ← XS202605130001
│       │       └── [1] 采购申请        ← CG202511100008
│       ├── [1] 合同申请
│       └── ...
```

### 成功响应（树形结构示例）

```json
{
  "code": "000",
  "message": "success",
  "data": [
    {
      "id": 7915479,
      "serialNumber": "P202604454442",
      "nodeName": "商机录入",
      "createTime": "2026-04-24 16:53:01",
      "taskId": "26575206",
      "processInstanceId": "26575206",
      "extendParams": "{...}",
      "dealUser": "dstest/dstest",
      "nodeId": "Activity_start",
      "executionId": "26575206",
      "status": "审核中",
      "amount": null,
      "percent": null,
      "businessTitle": "东方树叶测试商机0424",
      "taskLink": null,
      "actionUrl": null,
      "l4Name": "L4商机创建及验证",
      "l5Name": "商机录入",
      "stayDays": null,
      "sortOrder": 60,
      "outputName": "商机",
      "isRevoke": 0,

      "children": [
        {
          "id": 7915481,
          "serialNumber": "HT202605130001",
          "nodeName": "合同申请",
          "createTime": "2026-05-13 16:22:55",
          "taskId": "26625454",
          "processInstanceId": "26575206",
          "extendParams": "{...}",
          "dealUser": "于立君/yuljb",
          "nodeId": "Activity_contract_apply_ctc",
          "executionId": "26602528",
          "status": "审核中",
          "amount": "100",
          "percent": "0.33",
          "businessTitle": "1233546547",
          "taskLink": "/work/ctc/#/contract/contractDetail?contractNo={n_businessKey}&type=detail",
          "l4Name": "L4合同签订",
          "l5Name": "合同申请",
          "sortOrder": 260,
          "outputName": "合同申请",

          "children": [
            {
              "id": 7915480,
              "serialNumber": "XS202605130001",
              "nodeName": "生成订单",
              "createTime": "2026-05-13 16:32:29",
              "dealUser": "屠明漪/tumy",
              "status": "待处理",
              "amount": "100.0000",
              "percent": "100.00",
              "businessTitle": "1233546547",
              "taskLink": "/work/ctc/#/sales/salesDetail?saleInfoNumber={n_businessKey}&type=detail",
              "l4Name": "L4销售订单",
              "l5Name": "生成订单",
              "sortOrder": 315,
              "outputName": "生成订单",
              "children": null
            },
            {
              "id": 7915571,
              "serialNumber": "CG202511100008",
              "nodeName": "采购申请",
              "createTime": "2026-05-27 11:08:38",
              "dealUser": "刘婷婷/liuttg",
              "status": "审核中",
              "amount": "1",
              "percent": "1.00",
              "businessTitle": "ceshiBUG1110L1",
              "taskLink": "/work/ctc/#/purchase/purchaseDetail?purchaseNo={n_businessKey}&type=detail",
              "l4Name": "L4采购申请",
              "l5Name": "采购申请",
              "sortOrder": 330,
              "outputName": "采购申请",
              "children": null
            }
          ]
        }
      ]
    }
  ]
}
```

### 空数据响应

```json
{
  "code": "000",
  "message": "success",
  "data": []
}
```

## 字段说明

### 单据节点字段（每层节点通用）

| 字段 | 类型 | 说明 |
|------|------|------|
| id | integer | 单据记录 ID（数据库主键） |
| **serialNumber** | string | **单据编号**（如 P202604454442、HT202605130001、XS202605130001、CG202511100008） |
| nodeName | string | 节点名称（如 商机录入、合同申请、生成订单、采购申请） |
| createTime | string | 创建时间（格式：YYYY-MM-DD HH:mm:ss） |
| taskId | string | 任务 ID（流程引擎任务标识） |
| processInstanceId | string | 流程实例 ID |
| extendParams | string | 扩展参数（JSON 字符串，含完整业务上下文信息，**需二次解析**） |
| extendParamsC | string | 子单据扩展参数（仅 children 节点存在，为子单据自身的业务上下文） |
| dealUser | string | 处理人（格式：姓名/工号,姓名/工号） |
| nodeId | string | 流程节点 ID（BPMN Activity ID，如 Activity_contract_apply_ctc） |
| executionId | string | 流程执行实例 ID |
| status | string | 状态（审核中/待处理/已完成 等） |
| amount | string | 金额 |
| percent | string | 占比百分比（如 "0.33"、"100.00"） |
| businessTitle | string | 业务标题（单据的业务名称） |
| taskLink | string | 任务链接（含 `{xxx}` 占位符，需用同层级 `extendParams` 中同名 key 的值替换，详见下方 URL 变量替换规则） |
| actionUrl | string | 操作链接（完整 URL，可能为 null） |
| l4Name | string | L4 层级名称（如 L4合同签订、L4销售订单、L4采购申请） |
| l5Name | string | L5 层级名称（如 合同申请、生成订单、采购申请） |
| stayDays | string/null | 停留天数 |
| sortOrder | integer | 排序编号（按流程顺序递增） |
| outputName | string | 输出名称（如 商机、合同申请、生成订单、采购申请） |
| parentTaskId | string | 父任务 ID（children 节点存在，指向父节点的 taskId） |
| isRevoke | integer | 是否已撤回（0=否，1=是） |
| dyOrder | string | 排序字段（通常为空字符串） |
| **children** | array/null | **★ 子单据数组（核心字段！）**：该节点下的关联业务单据，结构与父节点相同，可继续嵌套 |

### ⚠️ children 字段详解

- **顶层 data 数组**：通常只有 1 条记录（商机录入根节点），`children` 中包含所有业务单据
- **children 节点**：才是真正的业务单据（合同 HTxxx、订单 XSxxx、采购 CGxxx、框架 KJxxx）
- **嵌套结构**：children 可继续包含 children（如 合同 → 订单 + 采购），形成树形层级
- **叶子节点**：`children` 为 `null` 或空数组时表示该节点无子单据
- **遍历方式**：必须递归遍历所有层级的 `children` 才能获取完整单据列表

### serialNumber 编号规则

| 前缀 | 含义 | 示例 |
|------|------|------|
| P | 商机（Project/Opportunity） | P202604454442 |
| HT | 合同（HeTong） | HT202605130001 |
| XS | 销售订单（XiaoShou） | XS202605130001 |
| CG | 采购（CaiGou） | CG202604240001 |
| KJ | 框架（KuangJia） | KJ202604240001 |

### extendParams 解析示例

```json
{
  "formType": "contract_apply",
  "amount": 15000,
  "status": "approved",
  "contractNo": "HT202604270001",
  "signDate": "2026-05-12"
}
```

## 使用注意事项

### ⚠️ 常见错误

1. **混淆 instanceId 和 projectId**
   - `instanceId` 是流程实例 ID（字符串类型，如 "26612501"）
   - `projectId` 是项目数字 ID（整数类型，如 105868）
   - 本接口必须使用 `instanceId`，不要使用 `projectId`

2. **❌ 将返回数据当作扁平数组遍历（最常见错误）**
   - 顶层 `data` 数组通常只有 **1 条**记录（商机录入根节点）
   - **必须递归遍历 `children` 字段**才能获取合同、订单、采购等实际业务单据
   - 错误做法：直接遍历 `data` 数组 → 只会得到 1 条商机录入
   - 正确做法：从根节点的 `children` 开始递归收集

3. **extendParams 需要二次解析**
   - `extendParams` 字段是 JSON 字符串，不是 JSON 对象
   - 需要使用 `JSON.parse()` 或类似方法解析后才能获取详细业务信息
   - 不同节点的 extendParams 结构可能不同
   - children 节点还有额外的 `extendParamsC` 字段，包含子单据自身的业务上下文

4. **taskLink 占位符替换**
   - `taskLink` 中包含 `{n_businessKey}` 或 `{businessKey}` 占位符
   - 使用时需替换为当前节点的 `serialNumber` 值才能生成有效链接

- **⚠️ URL 变量替换规则**：taskLink 中可能包含 `{xxx}` 占位符，需用同层级 `extendParams`（JSON 字符串）中同名 key 的值替换：
  - `{n_businessKey}` → 取 extendParams.n_businessKey
  - `{businessKey}` → 取 extendParams.businessKey（n_ 前缀优先，不存在时回退）
  - `{n_id}` → 取 extendParams.n_id
  - `{id}` → 取 extendParams.id
  - URL 以 `/work/` 开头时需补全为 `http://10.0.21.38:8080/work/...`
  - 替换后展示为可点击超链接，如：[查看合同详情](http://10.0.21.38:8080/work/ctc/#/contract/contractDetail?contractNo=HT202604240004&type=detail)

5. **单据数量可能较多**
   - 返回的是该项目全生命周期的所有单据记录（树形结构）
   - 对于长期运行的大型项目，嵌套层级可能较深
   - 注意递归深度和性能

### ✅ 最佳实践

1. **从项目列表获取 instanceId 后查询**
   ```python
   # 先获取项目列表，拿到项目的 instanceId
   instance_id = project["instanceId"]  # 如 "26612501"
   # 再用 instanceId 查询关联的单据列表
   requisitions = get_requisition_relation(instance_id)
   ```

2. **★ 递归遍历 children 获取所有单据（推荐）**
   ```python
   import json

   def collect_all_docs(nodes, results=None, depth=0):
       """递归收集树形结构中所有单据（含 children 嵌套）"""
       if results is None:
           results = []
       if not nodes:
           return results
       for node in nodes:
           # 记录当前节点（含根节点）
           results.append({
               "serialNumber": node.get("serialNumber"),
               "nodeName": node.get("nodeName"),
               "l5Name": node.get("l5Name"),
               "dealUser": node.get("dealUser"),
               "status": node.get("status"),
               "amount": node.get("amount"),
               "businessTitle": node.get("businessTitle"),
               "createTime": node.get("createTime"),
               "depth": depth  # 层级深度，方便区分根/子/孙节点
           })
           # 递归处理 children
           children = node.get("children")
           if children:
               collect_all_docs(children, results, depth + 1)
       return results

   # 使用：传入顶层 data 数组
   all_docs = collect_all_docs(requisitions)
   for doc in all_docs:
       prefix = "  " * doc["depth"]  # 缩进展示层级
       print(f"{prefix}[{doc['serialNumber']}] {doc['nodeName']} ({doc['l5Name']})")
       print(f"{prefix}  处理人: {doc['dealUser']} | 状态: {doc['status']}")
   ```

3. **仅获取叶子单据（跳过根节点）**
   ```python
   def collect_leaf_docs(nodes, results=None):
       """只收集有实际业务含义的子单据（children 节点），跳过商机录入等根节点"""
       if results is None:
           results = []
       if not nodes:
           return results
       for node in nodes:
           children = node.get("children")
           if children:
               # 有 children 则递归进入
               collect_leaf_docs(children, results)
           elif node.get("serialNumber"):
               # 无 children 且有编号 → 叶子单据
               results.append(node)
       return results

   leaf_docs = collect_leaf_docs(requisitions)
   print(f"共 {len(leaf_docs)} 张业务单据:")
   for doc in leaf_docs:
       print(f"  [{doc['serialNumber']}] {doc['nodeName']} - {doc['businessTitle']}")
   ```

4. **解析 extendParams / extendParamsC 获取详细信息**
   ```python
   import json

   for doc in all_docs:
       serial = doc.get("serialNumber", "-")

       # 优先使用 extendParamsC（子单据自身上下文），回退到 extendParams
       ext_raw = doc.get("extendParamsC") or doc.get("extendParams") or "{}"
       try:
           ext_params = json.loads(ext_raw)
           form_type = ext_params.get("formType", "-")
           biz_key = ext_params.get("businessKey", "-")
           n_biz_title = ext_params.get("n_businessTitle", "-")  # 子单据标题在 n_ 前缀字段
           print(f"  {serial} | 表单类型:{form_type} | 业务Key:{biz_key} | 标题:{n_biz_title}")
       except (json.JSONDecodeError, TypeError):
           print(f"  {serial} | 扩展参数解析失败")
   ```

5. **按单据类型分类统计**
   ```python
   from collections import defaultdict

   type_stats = defaultdict(int)
   for doc in leaf_docs:
       l5_name = doc.get("l5Name", "unknown")
       type_stats[l5_name] += 1

   for doc_type, count in sorted(type_stats.items(), key=lambda x: x[1], reverse=True):
       print(f"{doc_type}: {count} 条")
   ```

6. **关联跳转**
   - 通过 `taskId` 可跳转到具体任务详情页
   - 通过 `serialNumber` 可定位到具体的业务单据
   - `taskLink` 含 `{n_businessKey}` 占位符，使用时替换为当前节点的 `serialNumber`

## 相关 API

- **项目详情**: `GET /dy/project/getProjectDetail?id={projectId}` - 查询项目完整信息获取 instanceId
- **项目概览**: `GET /dy/project/getProjectOverview?id={projectId}` - 查询项目基本信息
- **操作历史**: `GET /dy/project/getFlowHostroyInfo?id={projectId}` - 查看完整操作历史和审批链路
- **项目列表**: `POST /dy/project/list` - 查询项目列表获取 instanceId

## 版本历史

- **2026-06-10**: 修正返回结构描述：接口实际返回**树形结构**（非扁平数组），业务单据在 `children` 节点中；补充完整字段表、children 详解、递归遍历示例、serialNumber 编号规则
- **2026-06-10**: 初始版本，记录项目单据/申请单查询 API 使用规范

---

**最后更新**: 2026-06-10
**维护者**: DST 团队
**适用场景**: 业务单据查询、申请单追踪、项目单据统计分析
