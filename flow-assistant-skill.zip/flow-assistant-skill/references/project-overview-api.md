# 📄 getProjectOverview API 使用规范

## API 端点

```
GET http://10.0.21.38:8080/dy/project/getProjectOverview
⚠️ 此接口仅支持 GET 方法（已实测验证 2026-06-10，参数通过 URL query string 传递）
```

## 请求参数

| 参数 | 类型 | 必填 | 说明 | 示例 |
|------|------|------|------|------|
| `id` | integer | 是 | 项目 ID（不是 instanceId） | `105868` |

## 调用示例

```bash
curl -s "http://10.0.21.38:8080/dy/project/getProjectOverview?id=105868" \
  -H "iv-user: dstest" \
  -H "Accept: *" \
  -H "Referer: http://10.0.21.38/" \
  -H "systemcode: AGENT" \
  --insecure
```

## 返回结构

### 成功响应（DyProjectOverViewDTO）

```json
{
  "code": "000",
  "message": "SUCCESS",
  "exceptionMessage": null,
  "timestamp": 1780989082598,
  "feedback": null,
  "data": {
    "id": 105868,
    "sjId": "P202605454450",
    "dyProjectName": "金辛阿里云派资 20260225-3600",
    "dyCustomerName": "上海伊泰实业有限公司",
    "amountTotal": "15000.00",
    "amountReceived": "0",
    "dyCreateTime": "2026-05-11 15:35:14",
    "dyEndTime": null,
    "instanceId": "26612501",
    "dept": "默认部门",
    "creator": "dstest/dstest",
    "flowStatus": "1",
    "todoData": {
      "others": [...],
      "L2 商机运作": [...]
    },
    "recentActivities": [...]
  }
}
```

### todoData 结构

`todoData` 字段包含该项目的全部待办任务，按 L2 阶段分组：

```json
{
  "todoData": {
    "others": [
      {
        "nodeId": "Activity_oppo_loss",
        "taskName": "商机输单",
        "createTime": "2026-05-11 15:35:07",
        "assigneeName": "刘红玉/liuhyc,王茹/wangru,dstest/dstest",
        "status": "商机出现",
        "amount": 15000
      }
    ],
    "L2 商机运作": [
      {
        "nodeId": "Activity_follow_up",
        "taskName": "商机跟进 - 商机出现",
        "l2Name": "L2 商机运作",
        "l5Name": "商机跟进",
        "createTime": "2026-05-11 15:35:07",
        "assigneeName": "刘红玉/liuhyc,dstest/dstest",
        "formType": "out"
      },
      {
        "nodeId": "Activity_oppo_qualify",
        "taskName": "商机 qualify",
        "l2Name": "L2 商机运作",
        "l5Name": "商机 qualify",
        "createTime": "2026-05-11 15:35:07",
        "assigneeName": "王茹/wangru,dstest/dstest",
        "formType": "out"
      }
    ]
  }
}
```

## 字段说明（DyProjectOverViewDTO）

### 项目基本信息

| 字段 | 类型 | 说明 |
|------|------|------|
| `id` | integer | 项目唯一标识（主键） |
| `sjId` | string | 商机编号（如 `P202605454450`） |
| `dyProjectName` | string | 项目名称 |
| `dyCustomerName` | string | 客户名称 |
| `amountTotal` | string | 项目总金额 |
| `amountReceived` | string | 已收回金额 |
| `dyCreateTime` | string | 创建时间（格式：`YYYY-MM-DD HH:mm:ss`） |
| `dyEndTime` | string | 结束时间（格式：`YYYY-MM-DD HH:mm:ss`，可能为 null） |
| `instanceId` | string | 流程实例 ID |
| `dept` | string | 所属部门 |
| `creator` | string | 创建人（格式：`工号/姓名`） |
| `flowStatus` | string | 流程状态（枚举值见下表） |
| `todoData` | object | 待办任务数据（按 L2 阶段分组，结构见下文） |
| `recentActivities` | array | 最近活动记录列表 |

### flowStatus 枚举值

| 值 | 说明 |
|----|------|
| 0 | 草稿 |
| 1 | 进行中 |
| 2 | 已完成 |
| 3 | 已取消 |

### 待办任务字段

| 字段 | 类型 | 说明 |
|------|------|------|
| `nodeId` | string | 节点 ID（如 `Activity_follow_up`） |
| `taskName` | string | 任务名称 |
| `createTime` | string | 创建时间 |
| `l2Name` | string | L2 阶段名称（可能为 null） |
| `l5Name` | string | L5 阶段名称（可能为 null） |
| `assigneeName` | string | 处理人列表（格式：`姓名/工号，姓名/工号`） |
| `businessTitle` | string | 业务标题（项目名称） |
| `businessKey` | string | 业务编号（商机编号） |
| `formType` | string | 表单类型（`out` 表示输出任务） |
| `extendParams` | string | 扩展参数（JSON 字符串，包含详细信息） |

## 使用注意事项

### ⚠️ 常见错误

1. **使用 instanceId 而非 id**
   - ❌ 错误：`id=26612501`（instanceId）
   - ✅ 正确：`id=105868`（项目 ID）
   - 结果：使用 instanceId 返回 `data: null`

2. **缺少必要请求头**
   - 必须包含 `iv-user` 和 `systemcode: AGENT`
   - 缺少这些头可能返回 `data: null`

3. **GET 请求使用 POST 参数**
   - 该接口仅支持 GET 方法
   - 使用 POST 会返回 `data: null`

### ✅ 最佳实践

1. **检查返回码**
   ```python
   if result.get("code") == "000" and result.get("data"):
       # 成功获取数据
       todo_data = result["data"].get("todoData")
       flow_status = result["data"].get("flowStatus")
   else:
       # 数据为空或错误
       todo_data = None
   ```

3. **解析 assigneeName 字段**
   - 格式：`姓名 1/工号 1，姓名 2/工号 2`
   - 可以用逗号分割获取多个处理人
   - 用斜杠分割获取姓名和工号

4. **检查 todoData 分组**
   - `others`: 其他待办（不属于特定 L2 阶段）
   - `L2 商机运作`: L2 阶段名称
   - 遍历所有 key 获取全部待办

## Python 解析示例

```python
import json
import urllib.request

def get_project_todo(project_id, user_id="dstest"):
    """获取项目待办详情"""

    url = f"http://10.0.21.38:8080/dy/project/getProjectOverview?id={project_id}"

    req = urllib.request.Request(url)
    req.add_header('iv-user', user_id)
    req.add_header('systemcode', 'AGENT')

    with urllib.request.urlopen(req) as response:
        result = json.loads(response.read().decode('utf-8'))

    if result.get("code") == "000" and result.get("data"):
        return result["data"].get("todoData"), result["data"].get("flowStatus")
    return None, None

# 使用示例
todo_data, flow_status = get_project_todo("105868")

if todo_data:
    print(f"流程状态：{flow_status}")
    print("项目待办详情:")
    for stage_name, tasks in todo_data.items():
        print(f"\n{stage_name}:")
        for task in tasks:
            print(f"  - {task['taskName']}")
            print(f"    处理人：{task['assigneeName']}")
            print(f"    创建时间：{task['createTime']}")
```

## 相关 API

- **待办汇总**: `POST /dy/myTask/todoListLevel5` - 获取用户待办
- **任务详情**: `POST /dy/myTask/getTaskDetailByL5Id` - 获取 L5 任务详情
- **流程审批**: `POST /dy/approval/process` - 处理审批操作

## 版本历史

- **2026-06-10**: 更新为 DyProjectOverViewDTO Schema 定义，修正 systemcode 为 AGENT
- **2026-06-09**: 初始版本，记录 `getProjectOverview` API 使用经验
- 发现使用项目 `id` 而非 `instanceId` 才能获取 `todoData`
