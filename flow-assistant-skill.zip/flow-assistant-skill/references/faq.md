# LTC 流程小助手常见问题 FAQ

## 一、待办任务相关问题

### Q1: 为什么查询不到我的待办任务？

**可能原因：**
1. **工号错误** - 使用的 iv-user 工号不是当前会话的正确工号
2. **无权限** - 该工号没有查询待办的权限
3. **暂无任务** - 当前确实没有分配的待办任务
4. **系统延迟** - 刚完成任务，系统数据还未同步

**解决方案：**
```bash
# 1. 确认工号是否正确
# 询问用户：请问当前会话使用哪个工号调用 API？

# 2. 检查返回码
# code: '000' 表示成功，但 data.result 可能为空
# code: '999' 表示方法不支持
# code: '401/403' 表示无权限

# 3. 尝试其他查询方式
# 如果待办为空，可查询项目列表，查看是否有参与的项目
```

**用户提示模板：**
> "当前会话未查询到相关待办任务，可能是：
> 1) 使用的工号不正确；2) 该工号暂无待办任务；3) 系统数据延迟。
> 请确认工号是否正确，或稍后再试。"

---

### Q2: 为什么待办列表中没有处理人信息？

**原因：**
- 系统限制 - 待办任务接口的 `processer` 字段经常返回空或 `N/A`
- 这是系统已知问题，不是配置错误

**解决方案：**
- 通过项目详情接口 (`/dy/project/getProjectOverview`) 查询待办任务的分配人
- 项目详情中的 `todoData.assigneeName` 字段包含处理人信息

**示例：**
```python
# 项目详情中的处理人信息
todo_data = result["data"]["todoData"]
for stage, tasks in todo_data.items():
    for task in tasks:
        print(f"任务：{task['taskName']}")
        print(f"处理人：{task['assigneeName']}")  # 例如："刘红玉/liuhyc,dstest/dstest"
```

---

### Q3: 如何理解待办汇总数据中的 L4/L5 层级？

**说明：**
- **L4 节点** - 较大的业务分类（如"合同签约"、"确收回款"）
- **L5 节点** - 具体的业务节点（如"合同申请"、"合同审核"）

**数据结构：**
```json
{
  "code": "000",
  "data": [
    {
      "l4Id": 60119,
      "l4Name": "合同签约",
      "l5List": [
        {
          "l5Id": 60147,
          "l5Name": "合同申请",
          "todoCount": 1151,
          "maxStayTime": "318 天 17 小时"
        },
        {
          "l5Id": 90097,
          "l5Name": "合同审核",
          "todoCount": 67,
          "maxStayTime": "318 天 16 小时"
        }
      ]
    }
  ]
}
```

**使用方式：**
- `l4Name` - 查看某一大类有多少待办
- `l5Name + l5Id` - 查询具体节点的待办明细

---

## 二、项目查询相关问题

### Q4: 为什么项目详情返回 `data: None`？

**原因：**
1. **使用了错误的 ID 类型**
   - ❌ 错误：使用 `instanceId`（流程实例 ID）
   - ✅ 正确：使用 `id`（项目 ID）

2. **缺少必要请求头**
   - 必须包含 `iv-user` 和 `systemcode: DIGITRAY`

3. **项目不存在或无权限**
   - 项目 ID 无效或当前用户无权访问

**错误示例：**
```bash
# ❌ 错误：使用 instanceId
curl "http://10.0.21.38/dy/project/getProjectOverview?id=26612501"

# ✅ 正确：使用项目 id
curl "http://10.0.21.38/dy/project/getProjectOverview?id=105868"
```

**解决方案：**
```python
# 从项目列表获取正确的 id
projects = get_project_list()
for project in projects:
    project_id = project['id']  # 正确：项目 ID
    instance_id = project['instanceId']  # 不要使用这个
```

---

### Q5: 项目列表返回 `code: '000'` 但 `data.result` 为空，是什么意思？

**含义：**
- 请求本身成功，但查询条件无匹配结果
- 常见原因：
  1. 用户无对应权限
  2. 查询条件过滤了所有项目
  3. 用户确实没有参与的项目

**与错误的区别：**
- `code: '000'` + 空列表 = 成功查询但无数据
- `code: '999'` + 错误信息 = 接口调用失败
- `code: '401/403'` + 错误信息 = 无权限

**用户提示：**
> "当前会话未查询到相关项目，可能是：
> 1) 使用的工号没有项目参与权限；2) 查询条件过于严格；3) 暂无相关项目记录。
> 建议：确认工号、放宽查询条件、或查询所有项目列表。"

---

### Q6: 如何查询项目的审批历史？

**接口：** `GET /dy/project/getFlowHostroyInfo`

**参数：**
- `id` - 项目 ID（不是 instanceId）
- `iv-user` - 用户工号
- `systemcode` - 系统代码（DIGITRAY）

**示例：**
```bash
curl 'http://10.0.21.38/dy/project/getFlowHostroyInfo?id=105868' \
  -H 'iv-user: dstest' \
  -H 'systemcode: DIGITRAY' \
  --insecure
```

**返回数据：**
```json
{
  "code": "000",
  "data": {
    "recentActivities": [
      {
        "taskName": "合同申请",
        "operator": "张 Three/zhangsan",
        "createTime": "2026-05-15 10:30:00",
        "remark": "审批通过"
      }
    ]
  }
}
```

---

## 三、流程相关问题

### Q7: 做完 XX 之后下一步是什么？

**回答方式：**
按 LTC 9 阶段流程顺序说明后续步骤。

**示例：**
> 问："合同签约之后做什么？"
> 
> 答：
> 合同签约之后，流程进入合同交付阶段，具体步骤：
> 1. **合同交付阶段**
>    - 订单拆分
>    - 同步订单
>    - 指派项目经理
>    - 项目启动
> 2. **确收回款阶段**
>    - 确收申请
>    - 确收审核
> 3. **合同开票阶段**
>    - 开票申请
>    - 开票审核
>    - 发票开具
> 4. **项目验收/结项阶段**
>    - 项目验收申请
>    - 项目验收审核
>    - 项目关闭
>    - 管理结项

---

### Q8: 如何理解 BPMN 流程图中的节点和连线？

**节点类型：**
- **UserTask（用户任务）** - 需要人工处理的任务节点
- **Gateway（网关）** - 流程分支条件判断
- **SequenceFlow（连线）** - 节点之间的流转方向

**关键信息：**
- **节点名称** - 节点的业务含义（如"合同申请"）
- **审批人** - 节点的处理人（assignee 或 candidateUsers）
- **表单** - 节点对应的业务表单标识
- **流转条件** - 连线上的条件表达式（如 `${amount>10000}`）

**使用脚本解析：**
```bash
python3 scripts/parse_bpmn_xml.py http://10.0.21.38/dy/flowable/definition/readXml/26667672
```

---

## 四、API 调用相关问题

### Q9: 为什么有些接口返回 `code: '999'`？

**含义：** 方法不支持

**常见场景：**
1. 接口仅支持 GET 方法，但使用了 POST
2. 接口仅支持 POST 方法，但使用了 GET
3. Content-Type 头设置错误

**解决方案：**
```bash
# 场景 1：POST 失败，尝试 GET
curl -X GET "http://10.0.21.38/dy/project/list?flowType=2"

# 场景 2：GET 失败，尝试 POST
curl -X POST http://10.0.21.38/dy/myTask/todoListLevel5 \
  -H "iv-user: dstest" -d '{}'
```

---

### Q10: 为什么接口调用超时或返回慢？

**原因：**
- 大数据量查询（如项目列表可能有上千条）
- 系统负载较高
- 网络延迟

**解决方案：**
```bash
# 1. 使用分页查询
curl -X POST http://10.0.21.38/dy/project/list \
  -H "iv-user: dstest" \
  -d '{"pageNum": 1, "pageSize": 5}'

# 2. 增加超时时间（30 秒）
curl -X POST http://10.0.21.38/dy/myTask/todoListLevel5 \
  -H "iv-user: dstest" \
  --connect-timeout 10 --max-time 30

# 3. 使用缓存（BPMN 流程定义缓存 24 小时）
```

---

## 五、权限和工号相关问题

### Q11: 为什么不同工号查询结果不同？

**原因：**
- 不同工号对应不同的项目和待办
- 某些工号有更高权限（如管理员）
- 项目参与权限按工号配置

**最佳实践：**
- **每次都向用户确认工号**
- 不要使用历史会话中的工号配置
- 用户未明确说明时询问："请问当前会话使用哪个工号调用 API？"

---

### Q12: 如何判断用户是否有权限查询某项目？

**判断方法：**
1. **尝试查询项目列表** - 如果该工号没有该项目，不会出现在列表中
2. **尝试查询项目详情** - 如果无权访问，返回 `data: None`
3. **检查返回码** - `code: '403'` 表示无权限

**建议：**
- 查询前先验证用户权限
- 无权限时友好提示："当前工号暂无该项目权限，请确认工号是否正确"

---

## 六、其他问题

### Q13: 什么是 B 端业务单？

**说明：**
- 业务单是业务系统中的基本记录单元
- 每个业务单有唯一的业务单号（businessKey）
- 业务单关联到具体的业务流程节点

**查询方式：**
```bash
# 通过 L5 ID 查询业务单明细
curl -X POST http://10.0.21.38/dy/myTask/getTaskDetailByL5Id \
  -H "iv-user: dstest" \
  -d '{"l5Id": 60147}'
```

---

### Q14: 如何理解项目金额和回款金额？

**字段说明：**
- **项目金额** - 合同总金额（含税）
- **已收回金额** - 已回款金额
- **未收回金额** - 项目金额 - 已收回金额

**数据来源：**
- 项目列表：`project['dyProjectAmount']`
- 项目详情：`project['amountTotal']` 和 `project['amountReceived']`

---

## 七、快速参考

### 常用接口速查

| 功能 | 接口 | 方法 | 说明 |
|------|------|------|------|
| 项目列表 | `/dy/project/list` | POST | 查询项目列表 |
| 项目详情 | `/dy/project/getProjectOverview` | GET | 查询项目详细信息 |
| 待办汇总 | `/dy/myTask/todoListLevel5` | POST | 查询待办任务汇总 |
| 任务明细 | `/dy/myTask/getTaskDetailByL5Id` | POST | 查询具体业务单明细 |
| 流程历史 | `/dy/project/getFlowHostroyInfo` | GET | 查询项目审批历史 |
| BPMN 定义 | `/dy/flowable/definition/readXml/{id}` | GET | 获取 BPMN 流程定义 |

### 常见返回码

| 返回码 | 含义 | 处理建议 |
|-------|------|---------|
| `000` | 成功 | 检查 data.result 是否为空 |
| `999` | 方法不支持 | 尝试相反的 HTTP 方法 |
| `401` | 未授权 | 检查 iv-user 工号 |
| `403` | 无权限 | 确认用户权限 |
| `404` | 资源不存在 | 检查资源 ID 是否正确 |
| `500` | 服务器错误 | 联系系统管理员 |

---

**最后更新**: 2026-06-09
**维护者**: DST 团队
**适用场景**: 用户常见问题解答、API 使用咨询、系统问题排查
