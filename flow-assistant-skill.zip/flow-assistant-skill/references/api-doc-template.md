# 📋 API 文档标准结构模板

## 用途
为 flow-assistant-skill 中的 API 文档提供统一的结构模板，确保每个 API 文档都包含必要的信息。

---

## 标准结构

### 1. API 端点

```
METHOD http://hostname:port/path/to/endpoint
```

### 2. 请求参数

#### 必传字段

| 参数名 | 类型 | 必填 | 说明 | 示例值 |
|--------|------|------|------|--------|
| param1 | string | 是 | 参数说明 | "value" |

#### 可选字段

| 参数名 | 类型 | 说明 |
|--------|------|------|
| param2 | string | 参数说明 |

### 3. 请求头

| 参数 | 值 | 必填 | 说明 |
|------|-----|------|------|
| iv-user | <user-id> | 是 | 用户工号 |
| Content-Type | application/json | 是 | 请求内容类型 |

### 4. 调用示例

#### 基础调用

```bash
curl -s -X POST http://10.0.21.38:8080/dy/myTask/todoListLevel5 \
  -H "iv-user: dstest" \
  -H "Content-Type: application/json" \
  -d '{}' \
  --insecure
```

#### 高级调用

```bash
# 带参数的示例
curl -X POST <url> -d '{"param1": "value1", "param2": "value2"}'
```

### 5. 返回结构

#### 成功响应

```json
{
  "code": "000",
  "message": "success",
  "data": {
    "result": []
  }
}
```

#### 空数据响应

```json
{
  "code": "000",
  "message": "success",
  "data": {
    "result": [],
    "total": 0
  }
}
```

### 6. 字段说明

| 字段 | 类型 | 说明 |
|------|------|------|
| code | string | 响应码，'000'表示成功 |
| message | string | 响应信息 |
| data | object | 数据主体 |

### 7. 使用注意事项

#### ⚠️ 常见错误

1. **参数错误** - 参数类型或值不符合要求
2. **权限不足** - 工号无权限访问
3. **数据为空** - 查询条件过严或确实无数据

#### ✅ 最佳实践

1. **验证返回数据** - 检查 code 字段是否为 '000'
2. **处理空数据** - 区分 "无数据" 和 "错误"
3. **使用缓存** - 对于不常变化的数据使用本地缓存

### 8. 相关 API

- **相关接口 1**: `METHOD /path/to/related`
- **相关接口 2**: `METHOD /path/to/related2`

### 9. 常见问题

#### Q: 问题 1？

**A**: 答案 1

#### Q: 问题 2？

**A**: 答案 2

### 10. 版本历史

- **YYYY-MM-DD**: 初始版本
- **YYYY-MM-DD**: 更新内容说明

---

**维护者**: DST 团队  
**最后更新**: YYYY-MM-DD
