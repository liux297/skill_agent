# 📄 FlowAssistant 项目列表 API 使用规范

## API 端点

```
POST http://10.0.21.38:8080/dy/project/flowAssistantProjectList
⚠️ 此接口仅支持 POST 方法（已实测验证 2026-06-10，GET 会返回参数转换错误）
```

## 请求参数

> 请求体结构与 `/dy/project/list` 完全一致（DyProjectPageReqDTO）

### 必传字段（5 个）

| 参数名 | 类型 | 必填 | 说明 | 示例值 |
|--------|------|------|------|--------|
| flowType | string | 是 | 查询范围：0-全部，1-我的项目，2-我参与的项目 | "1" |
| pageNum | int32 | 是 | 当前页码 | 1 |
| pageSize | int32 | 是 | 每页条数 | 5 |
| projectTime | number | 是 | **固定值 0** | 0 |
| businessOpportunityInfo | string | 是 | 商机名称/编号/项目名称（不查时传""） | "" |

### 可选字段

| 参数名 | 类型 | 说明 |
|--------|------|------|
| startTime | string | 起始时间，格式 yyyy-MM-dd HH:mm:ss |
| endTime | string | 终止时间 |
| itcode | string | 工号 |
| dyCustomerName | string | 客户名称 |
| projectAmountMin | number | 最小项目金额 |
| projectAmountMax | number | 最大项目金额 |

## 请求头

| 参数 | 值 | 必填 | 说明 |
|------|-----|------|------|
| iv-user | <user-id> | 是 | 用户工号（如 dstest） |
| Content-Type | application/json | 是 | 请求内容类型 |
| systemcode | AGENT | 是 | 系统编码 |
| Accept | */* | 是 | 接受任意内容类型 |

## 调用示例

### 基础调用

```bash
# ⚠️ 必须精简响应！同 /dy/project/list，只保留展示所需字段，避免响应超长被截断
curl -s -X POST http://10.0.21.38:8080/dy/project/flowAssistantProjectList \
  -H "iv-user: dstest" \
  -H "Content-Type: application/json" \
  -H "systemcode: AGENT" \
  -d '{"flowType":"1","pageNum":1,"pageSize":5,"projectTime":0,"businessOpportunityInfo":""}' \
  --insecure | python3 -c "
import json,sys
d=json.load(sys.stdin)
for p in d.get('data',{}).get('result',[]):
    for k in list(p.keys()):
        if k not in ('id','dyProjectName','dyCustomerName','dyProjectAmount','dyCreateTime','instanceId','creator','progressRate','todoList'):
            del p[k]
    for t in p.get('todoList',[]):
        for k in list(t.keys()):
            if k not in ('taskName','businessTitle','assigneeName','stayDays','taskLink','actionUrl','extendParams'):
                del t[k]
print(json.dumps(d,ensure_ascii=False))
"
```

### 按时间范围查询

```bash
curl -s -X POST http://10.0.21.38:8080/dy/project/flowAssistantProjectList \
  -H "iv-user: dstest" \
  -H "Content-Type: application/json" \
  -H "systemcode: AGENT" \
  -d '{
    "flowType": "1",
    "pageNum": 1,
    "pageSize": 50,
    "projectTime": 0,
    "businessOpportunityInfo": "",
    "startTime": "2026-05-01 00:00:00",
    "endTime": "2026-05-31 23:59:59"
  }' \
  --insecure
```

## 返回结构

### 成功响应（FlowAssistantProjectRespDTO）

与普通项目列表相比，每条项目记录额外携带 `todoList` 待办列表：

```json
{
  "code": "000",
  "message": "success",
  "data": {
    "result": [
      {
        "id": 105868,
        "sjId": "P202605454450",
        "dyProjectName": "金辛阿里云派资 20260225-3600",
        "dyCustomerName": "上海伊泰实业有限公司",
        "dyProjectAmount": 15000.00,
        "dyProjectAmountReceived": 0,
        "dyProjectStage": "L2 商机运作",
        "dyProjectStatus": "1",
        "dyProjectLeader": "dstest",
        "dyCreateTime": "2026-05-11 15:35:14",
        "dyUpdateTime": "2026-05-15 10:20:30",
        "deployId": "26667672",
        "instanceId": "26612501",
        "todoList": [
          {
            "nodeId": 60147,
            "processInstanceId": "26612501",
            "taskId": "26612503",
            "taskName": "合同申请",
            "createTime": "2026-05-11 15:35:14",
            "businessTitle": "金辛阿里云派资 20260225-3600",
            "businessKey": "P202605454450",
            "taskLink": "/task/detail/26612503",
            "formType": "contract_apply",
            "assignee": "dstest",
            "assigneeName": "张三",
            "l2Name": "合同签约",
            "l5Name": "合同申请",
            "sortOrder": 1,
            "stayDays": 3,
            "actionUrl": "/flow/action/submit",
            "preViewUrl": "/preview/26612503",
            "extendParams": {},
            "isOutput": true,
            "businessId": 105868
          }
        ]
      }
    ],
    "total": 880
  }
}
```

### 空数据响应

```json
{
  "code": "000",
  "message": "success",
  "data": {
    "result": [],
    "total": 0
  }
}
```

## 字段说明

### 项目基本信息（同 DyProjectPageRespDTO）

| 字段 | 类型 | 说明 |
|------|------|------|
| id | integer | 项目唯一标识（主键） |
| sjId | string | 商机编号 |
| dyProjectName | string | 项目名称（**展示时必须作为超链接**，链接格式：`http://10.0.21.38/#/workbench/projectDetail?id={id}`） |
| dyCustomerName | string | 客户名称 |
| dyProjectAmount | double | 项目总金额 |
| dyProjectAmountReceived | double | 已收回金额 |
| dyProjectStage | string | 项目阶段 |
| dyProjectStatus | string | 项目状态 |
| dyProjectLeader | string | 项目负责人工号 |
| dyCreateTime | string | 创建时间 |
| dyUpdateTime | string | 更新时间 |
| deployId | string | 流程部署 ID |
| instanceId | string | 流程实例 ID |

### todoList 待办列表（每条项目额外附带，DyProjectTodoDTO 数组）

| 字段 | 类型 | 说明 |
|------|------|------|
| nodeId | integer | 流程节点 ID |
| processInstanceId | string | 流程实例 ID |
| taskId | string | 任务 ID |
| taskName | string | 任务名称 |
| createTime | string | 任务创建时间 |
| businessTitle | string | 业务标题 |
| businessKey | string | 业务键 |
| taskLink | string | 任务链接 |
| formType | string | 表单类型 |
| assignee | string | 处理人工号（itcode） |
| assigneeName | string | 处理人姓名 |
| l2Name | string | L2 节点名称 |
| l5Name | string | L5 节点名称 |
| sortOrder | integer | 排序序号 |
| stayDays | number | 停留天数 |
| actionUrl | string | 操作 URL |
| preViewUrl | string | 预览 URL |
| extendParams | object | 扩展参数 |
| isOutput | boolean | 是否输出标记 |
| businessId | integer | 业务 ID |

### 分页信息

| 字段 | 说明 |
|------|------|
| result | 当前页的项目列表（每条带 todoList） |
| total | 总记录数 |

## 使用注意事项

### ⚠️ 与普通项目列表的区别

1. **额外返回 todoList**
   - 本接口在每条项目记录中额外嵌套了该项目的待办任务列表
   - 无需再单独调用 `getProjectTodoList` 接口

2. **请求参数完全相同**
   - 与 `/dy/project/list` 的 DyProjectPageReqDTO 结构一致
   - 可直接复用相同的查询条件

3. **性能考量**
   - 由于额外关联查询待办数据，响应可能比普通项目列表稍慢
   - 建议合理控制 pageSize（建议 ≤ 50）

### ✅ 最佳实践

1. **一次性获取项目和待办**
   ```python
   result = flow_assistant_project_list(flowType="1", pageNum=1, pageSize=10)
   for project in result["data"]["result"]:
       print(f"📋 {project['dyProjectName']}")
       for todo in project.get("todoList", []):
           print(f"   ⏳ {todo['taskName']} ({todo['stayDays']}天) -> {todo['assigneeName']}")
   ```

2. **筛选有待办的项目**
   ```python
   projects_with_todos = [p for p in result["data"]["result"] if p.get("todoList")]
   print(f"共 {len(projects_with_todos)} 个项目有待办任务")
   ```

3. **替代两次调用模式**
   ```
   旧模式: 调用 /dy/project/list → 遍历每个项目调用 /dy/project/getProjectTodoList
   新模式: 直接调用 /dy/project/flowAssistantProjectList（一次搞定）
   ```

## 相关 API

- **普通项目列表**: `POST /dy/project/list` - 仅返回项目基本信息（无待办）
- **项目待办列表**: `GET /dy/project/getProjectTodoList?id={projectId}` - 单个项目待办
- **项目详情**: `GET /dy/project/getProjectDetail?id={projectId}` - 含完整 nodeList
- **BPMN 流程定义**: `GET /dy/flowable/definition/readXml/{deployId}` - 获取流程定义 XML

## 版本历史

- **2026-06-10**: 初始版本，记录 FlowAssistant 项目列表 API 使用规范

---

**最后更新**: 2026-06-10
**维护者**: DST 团队
**适用场景**: 项目+待办一体化查询、减少接口调用次数、项目概览面板
