# 📄 项目待办列表 API 使用规范

## API 端点

```
GET http://10.0.21.38:8080/dy/project/getProjectTodoList?id={projectId}
⚠️ 此接口仅支持 GET 方法（已实测验证 2026-06-10，参数通过 URL query string 传递）
```

## 请求参数

| 参数名 | 类型 | 必填 | 说明 | 示例值 |
|--------|------|------|------|--------|
| id | integer | 是 | 项目 ID（来自项目列表的 `id` 字段） | 105868 |

## 请求头

| 参数 | 值 | 必填 | 说明 |
|------|-----|------|------|
| iv-user | <user-id> | 是 | 用户工号（如 dstest） |
| systemcode | AGENT | 是 | 系统编码 |
| Accept | */* | 是 | 接受任意内容类型 |

## 调用示例

### 基础调用

```bash
curl -s 'http://10.0.21.38:8080/dy/project/getProjectTodoList?id=105868' \
  -H 'iv-user: dstest' \
  -H 'systemcode: AGENT' \
  -H 'Accept: */*' \
  --insecure
```

### 使用 jq 格式化输出

```bash
curl -s 'http://10.0.21.38:8080/dy/project/getProjectTodoList?id=105868' \
  -H 'iv-user: dstest' \
  -H 'systemcode: AGENT' \
  -H 'Accept: */*' \
  --insecure | jq '.'
```

## 返回结构

### 成功响应

```json
{
  "code": "000",
  "message": "success",
  "data": [
    {
      "nodeId": 60147,
      "processInstanceId": "26612501",
      "taskId": "26612503",
      "taskName": "合同申请",
      "createTime": "2026-05-11 15:35:14",
      "businessTitle": "金辛阿里云派资 20260225-3600",
      "businessKey": "P202605454450",
      "taskLink": "/task/detail/26612503",
      "formType": "contract_apply",
      "assignee": "dstest",
      "assigneeName": "张三",
      "l2Name": "合同签约",
      "l5Name": "合同申请",
      "sortOrder": 1,
      "stayDays": 3,
      "actionUrl": "/flow/action/submit",
      "preViewUrl": "/preview/26612503",
      "extendParams": {},
      "isOutput": true,
      "businessId": 105868
    }
  ]
}
```

### 空数据响应

```json
{
  "code": "000",
  "message": "success",
  "data": []
}
```

## 字段说明

### DyProjectTodoDTO 字段

| 字段 | 类型 | 说明 |
|------|------|------|
| nodeId | integer | 流程节点 ID |
| processInstanceId | string | 流程实例 ID |
| taskId | string | 任务 ID（⭐ 用于跳转任务详情） |
| taskName | string | 任务名称 |
| createTime | string | 任务创建时间（格式：YYYY-MM-DD HH:mm:ss） |
| businessTitle | string | 业务标题（通常为项目名称） |
| businessKey | string | 业务键（通常为商机编号） |
| taskLink | string | 任务链接地址（可能含 `{xxx}` 占位符，需用同层级 `extendParams` 中同名 key 的值替换，详见下方 URL 变量替换规则） |
| formType | string | 表单类型标识 |
| assignee | string | 当前处理人工号（itcode） |
| assigneeName | string | 当前处理人姓名 |
| l2Name | string | L2 节点名称（业务大类） |
| l5Name | string | L5 节点名称（具体业务节点） |
| sortOrder | integer | 排序序号 |
| stayDays | number | 停留天数 |
| actionUrl | string | 任务操作 URL（可能含 `{xxx}` 占位符，替换规则同 taskLink） |
| preViewUrl | string | 预览页面 URL（可能含 `{xxx}` 占位符，替换规则同 taskLink） |
| extendParams | object | 扩展参数（JSON 对象） |
| isOutput | boolean | 是否输出标记 |
| businessId | integer | 关联业务 ID（项目 ID） |

## 使用注意事项

### ⚠️ 常见错误

1. **项目 ID 无效**
   - `id` 必须来自项目列表接口返回的 `id` 字段（整数主键）
   - 不要使用商机编号（sjId）或流程实例 ID（instanceId）

2. **权限不足**
   - 返回空数组可能是因为当前用户无权查看该项目待办
   - 确认 `iv-user` 为项目负责人或项目成员

3. **无待办记录**
   - `code: '000'` + `data: []` 表示该项目当前无待办任务
   - 这是正常情况，不是错误

4. **URL 变量替换规则**：taskLink/actionUrl/preViewUrl 中可能包含 `{xxx}` 占位符，需用同层级 `extendParams`（JSON 对象）中同名 key 的值替换：
   - `{n_businessKey}` → 取 extendParams.n_businessKey
   - `{businessKey}` → 取 extendParams.businessKey（n_ 前缀优先，不存在时回退）
   - `{n_id}` → 取 extendParams.n_id
   - `{id}` → 取 extendParams.id
   - URL 以 `/work/` 开头时需补全为 `http://10.0.21.38:8080/work/...`
   - 替换后展示为可点击超链接，如：[查看合同详情](http://10.0.21.38:8080/work/ctc/#/contract/contractDetail?contractNo=HT202604240004&type=detail)

### ✅ 最佳实践

1. **从项目列表获取 id 后查询待办**
   ```python
   # 先获取项目列表，拿到项目的 id
   project_id = project["id"]  # 如 105868
   # 再用 id 查询该项目的待办列表
   todo_list = get_project_todo_list(project_id)
   ```

2. **按停留时间排序展示**
   ```python
   todos = sorted(result.get("data", []), key=lambda x: x.get("stayDays", 0), reverse=True)
   for todo in todos:
       print(f"[{todo['stayDays']}天] {todo['taskName']} - {todo['assigneeName']}")
   ```

3. **关联跳转**
   - 通过 `taskId` 可跳转到具体任务详情页
   - 通过 `taskLink` 可生成前端跳转链接

## 相关 API

- **项目列表**: `POST /dy/project/list` - 查询项目列表获取 `id`
- **项目详情**: `GET /dy/project/getProjectDetail?id={projectId}` - 查询项目完整信息
- **FlowAssistant 项目列表**: `POST /dy/project/flowAssistantProjectList` - 一并返回项目及待办
- **BPMN 流程定义**: `GET /dy/flowable/definition/readXml/{deployId}` - 获取流程定义 XML

## 版本历史

- **2026-06-10**: 初始版本，记录项目待办列表 API 使用规范

---

**最后更新**: 2026-06-10
**维护者**: DST 团队
**适用场景**: 项目待办查询、任务跟踪、审批链路查看
