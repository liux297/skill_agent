# API 响应错误代码参考

## 概述

本文件记录了在使用 LTC 直客业务流程 API 时遇到的常见响应代码和错误模式。

## 响应代码含义

### ✅ 成功响应

#### `code: '000'` - 请求成功
```json
{
  "code": "000",
  "message": "success",
  "data": {
    "result": [...]
  }
}
```

**注意**：成功不代表有数据！需要检查 `data.result` 是否为空数组 `[]`。

**空数据场景**：
- 用户无对应权限
- 用户没有符合条件的数据
- 查询条件无匹配结果

---

### ⚠️ 常见非成功代码

#### `code: '999'` - 方法不支持
```json
{
  "code": "999",
  "message": "Method not supported"
}
```

**触发场景**：
- 使用 `GET` 请求但接口仅支持 `POST`
- 使用 `POST` 请求但接口仅支持 `GET`
- HTTP 方法与后端定义不匹配

**解决方法**：
1. 检查 API 文档确认支持的 HTTP 方法
2. 尝试相反的请求方法（如 POST 失败则试 GET）
3. 查看请求头中的 `Content-Type` 是否正确

---

#### 其他可能的错误代码

| 代码 | 含义 | 建议操作 |
|------|------|----------|
| `400` | 请求参数错误 | 检查请求参数格式和内容 |
| `401` | 未授权 | 检查 `iv-user` 工号是否正确 |
| `403` | 无权限 | 确认用户是否有访问权限 |
| `404` | 资源不存在 | 检查资源 ID 是否正确 |
| `500` | 服务器内部错误 | 联系系统管理员 |

---

## 调试技巧

### 1. 验证 iv-user 参数

```bash
# 正确示例
curl -X POST http://10.0.21.38:8080/dy/myTask/todoListLevel5 \
  -H "iv-user: dstest" \
  -H "Content-Type: application/json" \
  -d '{}' \
  --insecure

# 如果返回 401/403，尝试其他工号
```

### 2. 检查请求方法

```bash
# POST 接口
curl -X POST <url>

# GET 接口
curl -X GET <url>

# 如果不确定，两个都试
```

### 3. 解析完整响应

```bash
# 使用 jq 格式化输出
curl -s -X POST <url> \
  -H "iv-user: dstest" \
  -H "Content-Type: application/json" \
  -d '{}' \
  --insecure | jq '.'
```

### 4. 检查返回数据结构

```bash
# 检查 code 字段
curl -s -X POST <url> \
  -H "iv-user: dstest" \
  --insecure | jq '.code'

# 检查 data.result 是否存在
curl -s -X POST <url> \
  -H "iv-user: dstest" \
  --insecure | jq '.data.result | length'
```

---

## 常见错误模式

### 模式 1: `code: '000'` 但 `data.result` 为空

**现象**：
```json
{
  "code": "000",
  "message": "success",
  "data": {
    "result": []
  }
}
```

**原因**：
- 用户权限不足（如非负责人、非项目成员）
- 查询条件无匹配（如时间范围无数据）
- 数据尚未录入系统

**用户提示**：
> "当前会话未查询到相关数据，可能是权限不足或暂无相关记录。请确认：1) 使用的工号是否正确；2) 是否有对应项目的参与权限；3) 查询的时间范围是否有数据。"

---

### 模式 2: `code: '999'` - 方法不支持

**现象**：
```json
{
  "code": "999",
  "message": "Method not supported"
}
```

**常见场景**：
- `POST /dy/project/list` 在某些端点不支持
- `GET /dy/project/list` 可能在某些情况下返回数据

**解决方法**：
```bash
# 尝试 GET 方法
curl -s -X GET "http://10.0.21.38:8080/dy/project/list?flowType=2" \
  -H "iv-user: dstest" \
  --insecure | jq '.'

# 如果 GET 成功，以后使用 GET
```

---

### 模式 3: 请求头缺失导致失败

**现象**：
```json
{
  "code": "401",
  "message": "Unauthorized"
}
```

**常见问题**：
- 缺少 `iv-user` 请求头
- 缺少 `Content-Type: application/json`
- 请求头大小写错误（如 `IV-USER` 而非 `iv-user`）

**正确请求头格式**：
```bash
-H "iv-user: dstest"
-H "Content-Type: application/json"
-H "systemcode: AGENT"  # 部分接口需要
```

---

## 性能优化建议

### 1. 缓存策略

- **BPMN 流程定义**：首次请求后缓存 24 小时
- **项目列表**：按需查询，无需缓存（数据可能频繁变化）
- **待办任务**：实时查询，避免缓存过期

### 2. 批量查询

```bash
# 避免多次单独查询，使用批量接口
curl -s -X POST http://10.0.21.38:8080/dy/myTask/todoListLevel5 \
  -H "iv-user: dstest" \
  -H "Content-Type: application/json" \
  -d '{
    "pageNum": 1,
    "pageSize": 50,
    "filter": {"status": "pending"}
  }' \
  --insecure
```

### 3. 错误重试机制

```bash
# 遇到 500 错误时，自动重试 3 次
for i in {1..3}; do
  result=$(curl -s -X POST <url> -H "iv-user: dstest" -d '{}' --insecure)
  code=$(echo "$result" | jq -r '.code')
  if [ "$code" = "000" ] || [ "$code" = "999" ]; then
    echo "$result"
    break
  fi
  sleep 1
done
```

---

## 参考资源

- [BPMN 流程定义获取 API](./bpmn-definition-api.md) - BPMN 解析指南
- [API 调用失败处理模式](./api-failure-handling.md) - 失败处理策略
- [parse_bpmn_xml.py](../scripts/parse_bpmn_xml.py) - BPMN 解析脚本

---

**最后更新**: 2026-06-09
**维护者**: DST 团队
**适用场景**: LTC 直客业务流程 API 调用、错误排查、调试