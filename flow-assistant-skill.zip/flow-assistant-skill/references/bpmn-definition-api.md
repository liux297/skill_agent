# BPMN 流程定义获取 API

## API 说明

从流程定义接口获取 BPMN XML 文件，用于解析流程节点、流向等动态信息。

## 接口地址

```bash
GET http://10.0.21.38:8080/dy/flowable/definition/readXml/{deployId}
⚠️ 此接口仅支持 GET 方法（已实测验证 2026-06-10，参数通过 URL path 传递）
```

## 参数说明

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| deployId | String | 是 | 流程部署 ID（从项目列表或其他流程接口获取，与 Swagger 一致） |

## 请求头

| 字段 | 值 |
|------|-----|
| Accept | */* |
| iv-user | <user-id> |
| systemcode | AGENT |

## 示例请求

```bash
curl 'http://10.0.21.38:8080/dy/flowable/definition/readXml/26667672' \
  -H 'Accept: *' \
  -H 'iv-user: dstest' \
  -H 'systemcode: AGENT' \
  --insecure
```

## 返回数据

返回 BPMN XML 格式的文本内容，包含完整的流程定义信息，包括：

- 流程节点（UserTask、ServiceTask、Gateway 等）
- 节点属性（名称、ID、描述等）
- 节点之间的流向（SequenceFlow）
- 流程变量定义

## 使用建议

### 1. 缓存机制

首次调用该接口获取 BPMN XML 后，应：
- 解析 XML 为结构化 JSON
- 保存为本地缓存文件（如 `~/cache/bpmn_data/{deployId}.json`）
- 后续查询优先读取缓存
- 每日或定时更新缓存（缓存有效期 24 小时）

### 2. 解析内容

解析后的 JSON 应包含：

```json
{
  "deployId": "26667672",
  "processName": "LTC 直客流程",
  "nodes": [
    {
      "id": "userTask_1",
      "name": "商机录入",
      "type": "UserTask",
      "assignee": null,
      "candidateUsers": []
    },
    {
      "id": "gateway_1",
      "name": "审批通过？",
      "type": "ExclusiveGateway"
    }
  ],
  "flows": [
    {
      "id": "flow_1",
      "source": "userTask_1",
      "target": "gateway_1"
    }
  ]
}
```

### 3. 动态流程查询

使用缓存的 BPMN 数据可以：
- 查询当前节点之后的下一个节点
- 查询整个流程的路径
- 查询特定节点的处理人配置
- 根据流程实例状态动态匹配流程定义

## 注意事项

1. **deployId 获取**：从项目列表接口的 `deployId` 字段获取
2. **缓存有效期**：建议每日更新一次，避免频繁调用接口
3. **错误处理**：接口返回 `null` 或空内容时，可能是流程定义 ID 无效或权限不足
4. **权限验证**：确保 `iv-user` 对相应流程有查看权限

## 相关文件

- [API 端点发现与调试记录](./api-endpoint-discovery.md)
- [项目详情 API 使用规范](./project-overview-api.md)
