# 📄 项目操作历史 API 使用规范

## API 端点

```
GET http://10.0.21.38:8080/dy/project/getFlowHostroyInfo?id={projectId}&time={timestamp}
⚠️ 此接口仅支持 GET 方法（已实测验证 2026-06-10，参数通过 URL query string 传递）
```

## 请求参数

| 参数名 | 类型 | 必填 | 说明 | 示例值 |
|--------|------|------|------|--------|
| id | integer | 是 | 项目 ID（来自项目列表接口返回的 `id` 字段） | 105868 |
| time | string | 否 | 当前时间戳（毫秒），用于防止缓存，可用 $(date +%s%3N) 生成 | 1749600000000 |

## 请求头

| 参数 | 值 | 必填 | 说明 |
|------|-----|------|------|
| iv-user | <user-id> | 是 | 用户工号（如 dstest） |
| systemcode | AGENT | 是 | 系统编码 |
| Accept | */* | 是 | 接受任意内容类型 |

## 调用示例

### 基础调用

```bash
curl -s 'http://10.0.21.38:8080/dy/project/getFlowHostroyInfo?id=105868&time='$(date +%s%3N)'' \
  -H 'iv-user: dstest' \
  -H 'systemcode: AGENT' \
  -H 'Accept: */*' \
  --insecure
```

### 使用 jq 格式化输出

```bash
curl -s 'http://10.0.21.38:8080/dy/project/getFlowHostroyInfo?id=105868&time='$(date +%s%3N)'' \
  -H 'iv-user: dstest' \
  -H 'systemcode: AGENT' \
  -H 'Accept: */*' \
  --insecure | jq '.'
```

### 不带 time 参数调用

```bash
curl -s 'http://10.0.21.38:8080/dy/project/getFlowHostroyInfo?id=105868' \
  -H 'iv-user: dstest' \
  -H 'systemcode: AGENT' \
  -H 'Accept: */*' \
  --insecure
```

## 返回结构

### 成功响应（FlowHostroyResDTO）

```json
{
  "code": "000",
  "message": "success",
  "data": {
    "productName": "金辛阿里云派资 20260225-3600",
    "productId": "P202605454450",
    "customerName": "上海伊泰实业有限公司",
    "lastOperateTime": "2026-05-15 10:20:30",
    "instanceId": "26612501",
    "l2TaskList": [
      {
        "l2Name": "L2 商机运作",
        "l3List": [
          {
            "l3Name": "L3 商机立项",
            "l4List": [
              {
                "l4Name": "L4 需求确认",
                "l5TaskRespDTO": {
                  "taskList": [
                    {
                      "taskId": "26612503",
                      "taskName": "合同申请",
                      "businessTitle": "金辛阿里云派资 20260225-3600",
                      "ownerUser": "dstest",
                      "businessNo": "P202605454450",
                      "createTime": "2026-05-11 15:35:14",
                      "finishTime": "2026-05-12 09:00:00",
                      "endFlag": true
                    },
                    {
                      "taskId": "26612504",
                      "taskName": "采购审核",
                      "businessTitle": "金辛阿里云派资 20260225-3600",
                      "ownerUser": "lisi",
                      "businessNo": "P202604270001",
                      "createTime": "2026-05-12 14:20:00",
                      "finishTime": null,
                      "endFlag": false
                    }
                  ]
                }
              }
            ]
          }
        ]
      }
    ]
  }
}
```

## 字段说明

### 项目基本信息（FlowHostroyResDTO）

| 字段 | 类型 | 说明 |
|------|------|------|
| productName | string | 商机名称/项目名 |
| productId | string | 商机编号 |
| customerName | string | 客户公司名称 |
| lastOperateTime | string | 最后操作时间（格式：YYYY-MM-DD HH:mm:ss） |
| instanceId | string | 流程实例 ID |
| l2TaskList | array | L2 层级任务数组（按层级组织） |

### 层级任务结构（l2TaskList → l3List → l4List → l5TaskRespDTO → taskList）

#### l2TaskList 数组项

| 字段 | 类型 | 说明 |
|------|------|------|
| l2Name | string | L2 节点名称（业务大类） |
| l3List | array | L3 子节点数组 |

#### l3List 数组项

| 字段 | 类型 | 说明 |
|------|------|------|
| l3Name | string | L3 节点名称 |
| l4List | array | L4 子节点数组 |

#### l4List 数组项

| 字段 | 类型 | 说明 |
|------|------|------|
| l4Name | string | L4 节点名称 |
| l5TaskRespDTO | object | L5 任务响应对象 |

#### l5TaskRespDTO 对象

| 字段 | 类型 | 说明 |
|------|------|------|
| taskList | array | L5 具体任务列表 |

#### taskList 数组项（核心业务数据）

| 字段 | 类型 | 说明 |
|------|------|------|
| taskId | string | 任务 ID（唯一标识） |
| taskName | string | 任务名称（如 合同申请、采购审核） |
| businessTitle | string | 业务标题（通常为项目名称） |
| ownerUser | string | 处理人工号（itcode） |
| businessNo | string | 业务单号（如 P202604454442） |
| createTime | string | 创建时间（格式：YYYY-MM-DD HH:mm:ss） |
| finishTime | string | 完成时间（未完成时为 null） |
| endFlag | boolean | 是否结束（true=已结束，false=进行中） |

## 使用注意事项

### ⚠️ 常见错误

1. **项目 ID 无效**
   - `id` 必须来自项目列表接口返回的 `id` 字段（整数主键）
   - 不要使用商机编号（productId）或流程实例 ID（instanceId）

2. **time 参数缺失导致缓存**
   - 不传 `time` 参数可能返回缓存的旧数据
   - 建议始终传入当前时间戳以确保数据最新

3. **数据量较大**
   - 返回的是完整任务树，包含所有层级的所有任务记录
   - 对于大型项目，响应数据可能较大，注意处理性能

### ✅ 最佳实践

1. **递归遍历层级数据**
   ```python
   def traverse_task_tree(l2_list):
       """遍历完整的任务树，提取所有任务"""
       tasks = []
       for l2 in l2_list:
           if not l2.get("l3List"):
               continue
           for l3 in l2["l3List"]:
               if not l3.get("l4List"):
                   continue
               for l4 in l3["l4List"]:
                   l5_dto = l4.get("l5TaskRespDTO", {})
                   task_list = l5_dto.get("taskList", [])
                   tasks.extend(task_list)
       return tasks

   all_tasks = traverse_task_tree(data.get("l2TaskList", []))
   ```

2. **区分已完成和进行中的任务**
   ```python
   completed = [t for t in all_tasks if t.get("endFlag")]
   ongoing = [t for t in all_tasks if not t.get("endFlag")]
   print(f"已完成 {len(completed)} 个任务，进行中 {len(ongoing)} 个任务")
   ```

3. **与待办接口配合使用**
   - 如果只需要当前待办信息，建议使用 `getProjectTodoList`
   - 本接口适合需要完整历史记录和审批链路的场景

## 相关 API

- **项目概览**: `GET /dy/project/getProjectOverview?id={projectId}` - 查询项目基本信息和进度
- **项目待办**: `GET /dy/project/getProjectTodoList?id={projectId}` - 查询项目当前待办任务
- **项目详情**: `GET /dy/project/getProjectDetail?id={projectId}` - 查询项目完整详情和节点信息
- **单据查询**: `GET /dy/flowable/instance/getRequisitionRelation?instanceId={instanceId}` - 查询关联的业务单据

## 版本历史

- **2026-06-10**: 初始版本，记录项目操作历史 API 使用规范

---

**最后更新**: 2026-06-10
**维护者**: DST 团队
**适用场景**: 完整操作历史查看、审批链路追踪、项目全生命周期分析
