# API 调用失败处理模式

## 问题场景

在调用内部 API 时，可能出现以下失败情况：

```bash
# 网络无法访问到内部服务器
curl -s 'http://10.0.21.38:8080/dy/myTask/todoListLevel5' ...
# 输出为空
# 退出码：-1
```

## 诊断步骤

### 1. 检查响应特征

| 特征 | 含义 | 应对措施 |
|------|------|----------|
| 空输出 + exit_code: -1 | 网络连接失败或服务不可达 | 尝试缓存数据或提示用户 |
| 空输出 + exit_code: 0 | API 返回空数据（可能无权限） | 检查用户权限 |
| JSON 错误代码 | API 返回错误码（如 '999', '000'） | 查看错误代码文档 |

### 2. 检查缓存数据

当 API 调用失败时，应尝试使用本地缓存：

```bash
# 查找 BPMN 缓存文件（默认路径 ~/cache/bpmn_data/）
find ~/cache/bpmn_data -name "*.json"

# 检查缓存元数据
cat ~/cache/bpmn_data/26667672.meta.json
```

### 3. 判断缓存有效性

根据 `.meta.json` 中的时间戳判断：
- **created_at 为当天**：可以直接使用
- **created_at 非当天**：需要重新获取并更新

## 处理策略

### 策略 A：API 失败但有有效缓存

1. 检查是否存在缓存文件（`{deployId}.json` 和 `.meta.json`，默认路径 `~/cache/bpmn_data/`）
2. 验证缓存创建时间是否为当天
3. 如果缓存有效：
   - 告知用户"API 暂时不可用，使用今日缓存数据"
   - 继续处理并返回缓存数据
   - 建议在技能文档中标注"数据来源：缓存"

### 策略 B：API 失败且无缓存

1. 明确告知用户 API 调用失败
2. 提供可能的原因：
   - 网络连接问题
   - 内部服务未启动
   - 用户权限不足
3. 建议用户：
   - 检查网络连接
   - 直接登录系统查看
   - 稍后重试

## 错误处理代码模式

```python
import subprocess
import json
import os
from datetime import datetime

def query_with_fallback(api_url, user_id, cache_dir, deploy_id):
    """调用 API 并处理失败情况，优先使用缓存"""
    # 1. 尝试调用 API
    try:
        result = subprocess.run(
            ["curl", "-s", api_url, "-H", f"iv-user: {user_id}", "--insecure"],
            capture_output=True, text=True, timeout=30
        )
        if result.returncode == 0 and result.stdout.strip():
            return json.loads(result.stdout)
    except Exception as e:
        print(f"API 调用异常: {e}")

    # 2. API 失败，尝试读取缓存
    meta_file = f"{cache_dir}/{deploy_id}.meta.json"
    data_file = f"{cache_dir}/{deploy_id}.json"

    if os.path.exists(meta_file) and os.path.exists(data_file):
        with open(meta_file, 'r') as f:
            meta = json.load(f)
        created = datetime.fromisoformat(meta['created_at'])
        if created.date() == datetime.now().date():
            with open(data_file, 'r') as f:
                return json.load(f)

    # 3. 返回 None
    return None
```

## 最佳实践

1. **不要硬编码"API 不可用"**：网络问题可能是暂时的
2. **优先检查缓存**：缓存是有效的降级方案
3. **明确告知数据来源**：让用户知道使用的是缓存还是实时数据
4. **提供替代方案**：如果 API 失败，告诉用户如何手动查询
5. **记录失败原因**：在调试时记录具体错误信息

## 相关参考

- 📖 [API 响应错误代码参考](./api-error-codes.md) - 常见错误代码解析
- 📖 [BPMN 流程定义获取 API](./bpmn-definition-api.md) - 流程定义获取指南
- 📖 [项目详情 API 使用规范](./project-overview-api.md) - 项目查询最佳实践
