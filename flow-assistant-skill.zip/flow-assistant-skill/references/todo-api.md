# 📄 待办任务 API 使用规范

## API 端点

```
POST http://10.0.21.38:8080/dy/myTask/todoListLevel5
⚠️ 此接口仅支持 POST 方法（已实测验证 2026-06-10，GET 会返回 "Request method 'GET' not supported"）
```

## 请求参数

### 请求体（TodoL5QueryReqDTO）

支持以下可选查询条件，**默认传 `{}` 可查询全部待办**：

| 参数名 | 类型 | 必填 | 说明 | 示例值 |
|--------|------|------|------|--------|
| l5Name | string | 否 | L5 节点名称（模糊匹配） | "合同申请" |
| businessTitle | string | 否 | 业务标题（模糊匹配） | "上海伊泰" |
| businessKey | string | 否 | 业务键值 | "P202605454450" |
| createTimeStart | string | 否 | 创建时间起始，格式 yyyy-MM-dd HH:mm:ss | "2026-06-01 00:00:00" |
| createTimeEnd | string | 否 | 创建时间终止，格式 yyyy-MM-dd HH:mm:ss | "2026-06-30 23:59:59" |
| minStayDays | integer | 否 | 最小停留天数 | 5 |
| maxStayDays | integer | 否 | 最大停留天数 | 30 |

### 请求头

| 参数 | 值 | 必填 | 说明 |
|------|-----|------|------|
| iv-user | <user-id> | 是 | 用户工号（如 dstest） |
| Content-Type | application/json | 是 | 请求内容类型 |

## 调用示例

### 基础调用

```bash
curl -s -X POST http://10.0.21.38:8080/dy/myTask/todoListLevel5 \
  -H "iv-user: dstest" \
  -H "Content-Type: application/json" \
  -d '{}' \
  --insecure
```

### 使用 jq 格式化输出

```bash
curl -s -X POST http://10.0.21.38:8080/dy/myTask/todoListLevel5 \
  -H "iv-user: dstest" \
  -H "Content-Type: application/json" \
  -d '{}' \
  --insecure | jq '.'
```

## 返回结构

### 成功响应

```json
{
  "code": "000",
  "message": "success",
  "data": [
    {
      "l4Id": 60119,
      "l4Name": "合同签约",
      "l5List": [
        {
          "l5Id": 60147,
          "l5Name": "合同申请",
          "todoCount": 1151,
          "maxStayTime": "318 天 17 小时"
        },
        {
          "l5Id": 90097,
          "l5Name": "合同审核",
          "todoCount": 67,
          "maxStayTime": "318 天 16 小时"
        }
      ]
    },
    {
      "l4Id": 60120,
      "l4Name": "确收回款",
      "l5List": [
        {
          "l5Id": 60150,
          "l5Name": "确收申请",
          "todoCount": 204,
          "maxStayTime": "120 天 5 小时"
        }
      ]
    }
  ]
}
```

### 空数据响应

```json
{
  "code": "000",
  "message": "success",
  "data": []
}
```

## 字段说明

### 待办汇总结构

| 字段 | 类型 | 说明 |
|------|------|------|
| l4Id | integer | L4 节点 ID |
| l4Name | string | L4 节点名称（业务大类） |
| l5List | array | L5 节点列表 |

### L5 节点详情

| 字段 | 类型 | 说明 |
|------|------|------|
| l5Id | integer | L5 节点 ID（⭐ 查询明细时用） |
| l5Name | string | L5 节点名称（具体业务节点） |
| todoCount | integer | 待办任务数量 |
| maxStayTime | string | 最长停留时间（如 "318 天 17 小时"） |

## 数据层级说明

### L4 节点（业务大类）

L4 是较大的业务分类，例如：
- 合同签约
- 确收回款
- 合同开票
- 采购流程
- 项目验收/结项

### L5 节点（具体业务）

L5 是 L4 下的具体业务节点，例如：
- L4"合同签约"下的 L5：
  - 合同申请
  - 合同审核
  - 合同调整

## 使用注意事项

### ⚠️ 常见错误

1. **误以为返回 404 是错误**
   - 返回 `code: '000'` + `data: []` 表示用户无待办任务
   - 这是正常情况，不是错误

2. **使用错误的工号**
   - 返回空列表可能是因为工号没有待办权限
   - 务必向用户确认当前工号

3. **直接查询单个 L5 节点**
   - 本接口返回所有待办汇总
   - 如需查询具体任务明细，使用 `/dy/myTask/getTaskDetailByL5Id`

### ✅ 最佳实践

1. **解析返回数据**
   ```python
   def parse_todo_summary(todo_data):
       """解析待办汇总数据"""
       if not todo_data:
           return "当前无待办任务"
       
       result = []
       for l4 in todo_data:
           result.append(f"### {l4['l4Name']}")
           for l5 in l4['l5List']:
               result.append(
                   f"- **{l5['l5Name']}**: {l5['todoCount']} 个待办（最长停留：{l5['maxStayTime']}）"
               )
       return "\n".join(result)
   ```

2. **查询具体任务明细**
   ```bash
   # 从待办汇总获取 l5Id = 60147
   # 查询合同申请的明细
   curl -X POST http://10.0.21.38:8080/dy/myTask/getTaskDetailByL5Id \
     -H "iv-user: dstest" \
     -H "Content-Type: application/json" \
     -d '{"l5Id": 60147}' \
     --insecure
   ```

3. **处理异常数据**
   ```python
   if result.get("code") == "000":
       if not result.get("data"):
           print("当前无待办任务")
       else:
           for l4 in result["data"]:
               print(f"{l4['l4Name']}: {sum(l5['todoCount'] for l5 in l4['l5List'])} 个待办")
   ```

## 相关 API

- **任务明细**: `POST /dy/myTask/getTaskDetailByL5Id` - 查询 L5 节点的详细任务
- **项目列表**: `POST /dy/project/list` - 查询项目列表
- **项目详情**: `GET /dy/project/getProjectOverview` - 查询项目信息和待办

## 常见问题

### Q: 为什么待办汇总中没有处理人信息？

**A**: 系统限制 - 待办汇总接口的 `processer` 字段经常返回空。需要通过项目详情接口查询处理人信息。

### Q: 如何查询某个具体待办任务？

**A**: 
1. 先调用本接口获取待办汇总
2. 从汇总中找到对应 L5 节点，获取 `l5Id`
3. 调用任务明细接口 `/dy/myTask/getTaskDetailByL5Id` 传入 `l5Id` 查询具体任务

### Q: 为什么查询不到待办？

**A**: 可能原因：
1. 工号不正确
2. 该工号确实无待办任务
3. 系统数据延迟（刚完成任务）
4. 无权限访问

## 版本历史

- **2026-06-10**: 更新请求参数说明，补充 TodoL5QueryReqDTO 的 7 个可选查询条件
- **2026-06-09**: 初始版本，记录待办汇总 API 使用经验
- 包含数据层级说明（L4 → L5）
- 提供查询任务明细的完整流程

---

**最后更新**: 2026-06-10
**维护者**: DST 团队
**适用场景**: 待办任务查询、待办数量统计、任务明细关联
