# 📄 项目列表 API 使用规范

## API 端点

```
POST http://10.0.21.38:8080/dy/project/list
⚠️ 此接口仅支持 POST 方法（已实测验证 2026-06-10，GET 会返回参数转换错误）
```

## 请求参数

### 必传字段（1 个）

| 参数名 | 类型 | 必填 | 状态 | 说明 | 示例值 |
|--------|------|------|------|------|--------|
| projectTime | number | **是** | ✅ 可用 | **项目用时（唯一必填参数！不传则返回 999）**，一般固定传 `0` | 0 |

### 基础查询参数

| 参数名 | 类型 | 必填 | 状态 | 说明 | 示例值 |
|--------|------|------|------|------|--------|
| flowType | string | 否 | ✅ 可用 | 查询范围：0-全部，1-我的项目，2-我参与的项目 | "2" |
| pageNum / current | int32 | 否 | ✅ 可用 | 当前页码，默认1 | 1 |
| pageSize / size | int32 | 否 | ✅ 可用 | 每页条数，默认5，实测支持 1~100+ | 5 |
| businessOpportunityInfo | string | 否 | ✅ 可用 | 商机名称/编号/项目名称（模糊搜索，支持中文；不查时传空串或省略） | "" |

#### 项目筛选

| 参数名 | 类型 | 状态 | 说明 | 示例值 |
|--------|------|------|------|--------|
| startTime | string | ✅ 可用 | 起始时间，格式 yyyy-MM-dd 或 yyyy-MM-dd HH:mm:ss | "2026-04-01" |
| endTime | string | ✅ 可用 | 终止时间 | "2026-04-30" |
| dyCustomerName | string | ✅ 可用 | 客户名称（支持中文） | "华为" |
| projectAmountMin | number | ✅ 可用 | 最小项目金额 | 1000 |
| projectAmountMax | number | ✅ 可用 | 最大项目金额 | 50000 |
| dyProjectLeader | string | ✅ 可用 | 项目负责人 | "dstest" |
| projectStatus | string | ✅ 可用 | 项目状态 | "1" |
| projectStage | string | ❌ **不可用** | 流程阶段参数，**传任意值均返回 999**，请勿使用 | - |

#### 任务筛选

| 参数名 | 类型 | 状态 | 说明 | 示例值 |
|--------|------|------|------|--------|
| taskName | string | ✅ 可用 | 任务名称（模糊匹配，支持中文） | "合同审核" |
| taskAssignee | string | ✅ 可用 | 任务处理人姓名（支持中文） | "刘婷婷" |
| minTaskStayDays | integer | ✅ 可用 | 任务最小停留天数（含） | 5 |
| maxTaskStayDays | integer | ✅ 可用 | 任务最大停留天数（含） | 30 |
| taskStartTimeAfter | string | ✅ 可用 | 任务开始时间之后 | "2026-06-01" |

> **实测说明（2026-06-10）**：以上所有标注 ✅ 的参数均已通过实际 API 调用验证返回 code=000。`projectStage` 参数返回 999 为服务端限制。`projectTime` 是唯一真正必填的参数。

## 请求头

| 参数 | 值 | 必填 | 说明 |
|------|-----|------|------|
| iv-user | <user-id> | 是 | 用户工号（如 dstest） |
| Content-Type | application/json | 是 | 请求内容类型 |

## 调用示例

### 基础调用

```bash
# ⚠️ 必须精简响应！只保留展示所需字段，避免响应超长被截断
curl -s -X POST http://10.0.21.38:8080/dy/project/list \
  -H "iv-user: dstest" \
  -H "Content-Type: application/json" \
  -d '{"flowType":"2","pageNum":1,"pageSize":5,"projectTime":0,"businessOpportunityInfo":""}' \
  --insecure | python3 -c "
import json,sys
d=json.load(sys.stdin)
for p in d.get('data',{}).get('result',[]):
    for k in list(p.keys()):
        if k not in ('id','dyProjectName','dyCustomerName','dyProjectAmount','dyCreateTime','instanceId','creator','progressRate'):
            del p[k]
print(json.dumps(d,ensure_ascii=False))
"
```

### 按时间范围查询

```bash
curl -s -X POST http://10.0.21.38:8080/dy/project/list \
  -H "iv-user: dstest" \
  -H "Content-Type: application/json" \
  -d '{
    "flowType": "1",
    "pageNum": 1,
    "pageSize": 50,
    "projectTime": 0,
    "businessOpportunityInfo": "",
    "startTime": "2026-05-01 00:00:00",
    "endTime": "2026-05-31 23:59:59"
  }' \
  --insecure
```

### 按客户名称查询

```bash
curl -s -X POST http://10.0.21.38:8080/dy/project/list \
  -H "iv-user: dstest" \
  -H "Content-Type: application/json" \
  -d '{
    "flowType": "0",
    "pageNum": 1,
    "pageSize": 5,
    "projectTime": 0,
    "businessOpportunityInfo": "",
    "dyCustomerName": "上海伊泰实业有限公司"
  }' \
  --insecure
```

## 返回结构

### 成功响应

```json
{
  "code": "000",
  "message": "success",
  "data": {
    "result": [
      {
        "id": 105868,
        "dyProjectName": "金辛阿里云派资 20260225-3600",
        "dyCustomerName": "上海伊泰实业有限公司",
        "dyProjectAmount": 15000.00,
        "dyCreateTime": "2026-05-11 15:35:14",
        "instanceId": "26612501",
        "creator": "dstest",
        "progressRate": 65.5,
        "isNew": true,
        "viewDate": "2026-05-15 10:20:30",
        "nodeList": [
          {
            "nodeId": "node_001",
            "nodeName": "合同审核",
            "status": "completed"
          }
        ]
      }
    ],
    "total": 880
  }
}
```

### 空数据响应

```json
{
  "code": "000",
  "message": "success",
  "data": {
    "result": [],
    "total": 0
  }
}
```

### ⚠️ 数据路径说明

- **项目列表在 `data.result` 数组中**（不是顶层 `result` 字段）
- 解析时使用 `.data.result[]` 遍历项目列表
- `.data.total` 返回符合条件的项目总数（不受 pageSize 分页限制）
- 每条记录的 `nodeList` 是流程节点模板（含所有 BPMN 节点定义），不是当前项目的实际节点状态

## 字段说明

### 项目基本信息

| 字段 | 类型 | 说明 |
|------|------|------|
| id | integer | 项目唯一标识（主键） |
| dyProjectName | string | 项目名称（**展示时必须作为超链接**，链接格式：`http://10.0.21.38/#/workbench/projectDetail?id={id}`） |
| dyCustomerName | string | 客户名称 |
| dyProjectAmount | double | 项目总金额（含税） |
| dyCreateTime | string | 创建时间（格式：YYYY-MM-DD HH:mm:ss） |
| instanceId | string | 流程实例 ID |
| creator | string | 创建人工号 |
| progressRate | double | 项目进度百分比（0-100） |
| isNew | boolean | 是否为新项目（未查看过） |
| viewDate | string | 最后查看时间（格式：YYYY-MM-DD HH:mm:ss） |
| nodeList | array | 流程节点列表 |

### 节点信息（nodeList）

| 字段 | 类型 | 说明 |
|------|------|------|
| nodeId | string | 节点 ID |
| nodeName | string | 节点名称 |
| status | string | 节点状态（completed/active/pending） |

### 分页信息

| 字段 | 说明 |
|------|------|
| result | 当前页的项目列表 |
| total | 总记录数 |

## 使用注意事项

### ⚠️ 常见错误

1. **flowType 参数错误**
   - 0 = 全部项目（需要管理员权限）
   - 1 = 我的项目（作为负责人的项目）
   - 2 = 我参与的项目（作为项目成员的项目）

2. **projectTime 参数**
   - 固定值必须为 0
   - 其他值可能导致查询失败

3. **分页参数**
   - pageNum 从 1 开始（不是 0）
   - pageSize 建议不超过 100

4. **空数据含义**
   - `code: '000'` + `result: []` 表示成功查询但无数据
   - 可能是用户无权限或查询条件过严

### ✅ 最佳实践

1. **按时间范围查询**
   ```bash
   # 查询上周的项目
   curl -X POST <url> -d '{"startTime": "2026-05-12 00:00:00", "endTime": "2026-05-18 23:59:59"}'
   ```

2. **检查返回数据**
   ```python
   if result.get("code") == "000" and result.get("data", {}).get("result"):
       projects = result["data"]["result"]
       total = result["data"]["total"]
       print(f"共查询到 {total} 个项目，当前页 {len(projects)} 条")
   else:
       print("未查询到项目")
   ```

3. **使用 processDefinitionId**
   - 从项目列表获取 `processDefinitionId`
   - 用于查询 BPMN 流程定义：`/dy/flowable/definition/readXml/{processDefinitionId}`

## 相关 API

- **项目详情**: `GET /dy/project/getProjectOverview` - 查询项目详细信息和待办
- **待办任务**: `POST /dy/myTask/todoListLevel5` - 查询用户待办任务
- **任务明细**: `POST /dy/myTask/getTaskDetailByL5Id` - 查询 L5 节点的详细任务
- **BPMN 流程**: `GET /dy/flowable/definition/readXml/{id}` - 获取流程定义 XML

## 版本历史

- **2026-06-10**: 更新请求参数和响应字段，补充任务筛选参数，修正 DyProjectPageRespDTO 字段定义
- **2026-06-09**: 初始版本，记录项目列表 API 使用经验
- 包含必传字段、可选字段、返回结构说明
- 提供调用示例和常见错误处理

---

**最后更新**: 2026-06-10
**维护者**: DST 团队
**适用场景**: 项目查询、项目列表分析、流程定义获取
