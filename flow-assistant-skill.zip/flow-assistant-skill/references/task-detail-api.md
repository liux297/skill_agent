# 📄 任务明细 API 使用规范

## API 端点

```
POST http://10.0.21.38:8080/dy/myTask/getTaskDetailByL5Id
⚠️ 此接口仅支持 POST 方法（已实测验证 2026-06-10，GET 会返回 "Request method 'GET' not supported"）
```

## 请求参数

### 请求体（L5TaskDetailReqDTO）

```json
{
  "l5Id": 60147,
  "l5Name": "合同申请",
  "businessTitle": "",
  "businessKey": ""
}
```

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| l5Id | integer | 二选一 | L5 节点 ID（从待办汇总接口获取） |
| l5Name | string | 二选一 | L5 节点名称 |
| businessTitle | string | 否 | 业务标题（可选过滤条件） |
| businessKey | string | 否 | 业务单号（可选过滤条件） |

> **注意**：`l5Id` 和 `l5Name` 二选一即可，优先使用 `l5Id`

### 请求头

| 参数 | 值 | 必填 | 说明 |
|------|-----|------|------|
| iv-user | <user-id> | 是 | 用户工号（如 dstest） |
| Content-Type | application/json | 是 | 请求内容类型 |

## 调用示例

### 基础调用

```bash
curl -s -X POST http://10.0.21.38:8080/dy/myTask/getTaskDetailByL5Id \
  -H "iv-user: dstest" \
  -H "Content-Type: application/json" \
  -d '{"l5Id": 60147}' \
  --insecure
```

### 使用 jq 格式化输出

```bash
curl -s -X POST http://10.0.21.38:8080/dy/myTask/getTaskDetailByL5Id \
  -H "iv-user: dstest" \
  -H "Content-Type: application/json" \
  -d '{"l5Id": 60147}' \
  --insecure | jq '.'
```

## 返回结构

### 成功响应（L5TaskDetailRespDTO）

```json
{
  "code": "000",
  "message": "success",
  "data": [
    {
      "serialNumber": 1,
      "taskName": "合同申请",
      "stayDays": 5,
      "createTime": "2026-05-14 10:30:00",
      "operationType": "待审批",
      "redirectUrl": "/task/detail/60147",
      "l5Id": 60147,
      "l5Name": "合同申请",
      "totalCount": 3
    }
  ]
}
```

### 空数据响应

```json
{
  "code": "000",
  "message": "success",
  "data": []
}
```

## 字段说明（L5TaskDetailRespDTO）

| 字段 | 类型 | 说明 |
|------|------|------|
| serialNumber | integer | 序号 |
| taskName | string | 任务名称 |
| stayDays | integer | 停留天数 |
| createTime | string | 任务创建时间（格式：YYYY-MM-DD HH:mm:ss） |
| operationType | string | 操作类型（如"待审批"、"已审批"等） |
| redirectUrl | string | 跳转链接（已是完整 URL，无需变量替换，直接展示为可点击超链接即可） |
| l5Id | integer | L5 节点 ID |
| l5Name | string | L5 节点名称 |
| totalCount | integer | 该节点任务总数 |

## 使用注意事项

### ⚠️ 常见错误

1. **l5Id 参数错误**
   - 必须从待办汇总接口获取的 `l5Id`
   - 不能随意输入数字

2. **误以为返回 404 是错误**
   - 返回 `code: '000'` + `data: []` 表示该 L5 节点无任务
   - 这是正常情况

3. **工号权限不足**
   - 如果用户无权查看某些业务单，可能返回空数据

### ✅ 最佳实践

1. **完整调用流程**
   ```python
   # 步骤 1：查询待办汇总
   todo_summary = get_todo_summary()  # POST /dy/myTask/todoListLevel5
   
   # 步骤 2：找到对应 L5 节点
   for l4 in todo_summary["data"]:
       for l5 in l4["l5List"]:
           if l5["l5Name"] == "合同申请":
               l5_id = l5["l5Id"]
               break
   
   # 步骤 3：查询该 L5 节点的明细
   if l5_id:
       details = get_task_detail_by_l5_id(l5_id)  # POST /dy/myTask/getTaskDetailByL5Id
   ```

2. **使用 l5Id 或 l5Name 查询**
   - 支持按 `l5Id`（数字）或 `l5Name`（名称）查询
   - 优先使用 `l5Id`，更精确

3. **查看任务停留时间**
   - `stayDays` 字段显示任务已停留天数
   - 可用于判断任务处理时效

## 数据层级关系

```
待办汇总 → 任务明细 → 项目详情
  ↓           ↓          ↓
  汇总数据    业务单明细   完整信息
  L4/L5 节点    业务单 1:N  项目详情
```

### 调用流程

1. **查询待办汇总**
   ```bash
   POST /dy/myTask/todoListLevel5
   ```
   → 返回：`[{l4Id, l4Name, l5List: [{l5Id, l5Name, todoCount}]}]`

2. **查询任务明细**
   ```bash
   POST /dy/myTask/getTaskDetailByL5Id
   ```
   → 返回：`[{serialNumber, taskName, stayDays, operationType, ...}]`

3. **查询项目详情**（可选）
   ```bash
   GET /dy/project/getProjectOverview?id={projectId}
   ```
   → 返回：`{projectName, customerName, amountTotal, amountReceived, ...}`

## 相关 API

- **待办汇总**: `POST /dy/myTask/todoListLevel5` - 查询待办任务汇总（获取 l5Id/l5Name）
- **项目概览**: `GET /dy/project/getProjectOverview` - 查询项目详细信息
- **流程审批**: `POST /dy/approval/process` - 处理审批操作

## 常见问题

### Q: 为什么任务明细返回空？

**A**: 可能原因：
1. 该 L5 节点确实没有任务
2. 工号无权限查看该业务单
3. 任务已被处理或取消

### Q: 如何获取 L5 节点信息？

**A**:
- 从待办汇总接口返回的 `l5Id` 或 `l5Name` 字段获取
- 优先使用 `l5Id`（数字 ID），更精确
- 也支持直接使用 `l5Name`（节点名称）查询

### Q: 如何判断任务处理时效？

**A**:
- 使用 `stayDays` 字段查看任务已停留天数
- 结合 `operationType` 判断当前状态
- 可用于催办或超时提醒

## 版本历史

- **2026-06-10**: 更新为 L5TaskDetailReqDTO/L5TaskDetailRespDTO Schema 定义
- **2026-06-09**: 初始版本，记录任务明细 API 使用经验
- 包含完整调用流程和字段说明
- 提供与待办汇总、项目详情的关联关系

---

**最后更新**: 2026-06-10
**维护者**: DST 团队
**适用场景**: 业务单明细查询、待办任务详情、流程实例追踪
