# 📄 项目详情 API 使用规范

## API 端点

```
GET http://10.0.21.38:8080/dy/project/getProjectDetail?id={projectId}
⚠️ 此接口仅支持 GET 方法（已实测验证 2026-06-10，参数通过 URL query string 传递）
```

## 请求参数

| 参数名 | 类型 | 必填 | 说明 | 示例值 |
|--------|------|------|------|--------|
| id | integer | 是 | 项目 ID（来自项目列表的 `id` 字段） | 105868 |

## 请求头

| 参数 | 值 | 必填 | 说明 |
|------|-----|------|------|
| iv-user | <user-id> | 是 | 用户工号（如 dstest） |
| systemcode | AGENT | 是 | 系统编码 |
| Accept | */* | 是 | 接受任意内容类型 |

## 调用示例

### 基础调用

```bash
curl -s 'http://10.0.21.38:8080/dy/project/getProjectDetail?id=105868' \
  -H 'iv-user: dstest' \
  -H 'systemcode: AGENT' \
  -H 'Accept: */*' \
  --insecure
```

### 使用 jq 格式化输出

```bash
curl -s 'http://10.0.21.38:8080/dy/project/getProjectDetail?id=105868' \
  -H 'iv-user: dstest' \
  -H 'systemcode: AGENT' \
  -H 'Accept: */*' \
  --insecure | jq '.'
```

## 返回结构

### 成功响应（DyProjectPageRespDTO）

```json
{
  "code": "000",
  "message": "success",
  "data": {
    "id": 105868,
    "sjId": "P202605454450",
    "dyProjectName": "金辛阿里云派资 20260225-3600",
    "dyCustomerName": "上海伊泰实业有限公司",
    "dyProjectAmount": 15000.00,
    "dyProjectAmountReceived": 0,
    "dyProjectStage": "L2 商机运作",
    "dyProjectStatus": "1",
    "dyProjectLeader": "dstest",
    "dyCreateTime": "2026-05-11 15:35:14",
    "dyUpdateTime": "2026-05-15 10:20:30",
    "deployId": "26667672",
    "instanceId": "26612501",
    "nodeList": [
      {
        "nodeId": 60001,
        "nodeName": "商机录入",
        "nodeStatus": "completed",
        "assignee": "dstest",
        "assigneeName": "张三",
        "completeTime": "2026-05-11 16:00:00"
      },
      {
        "nodeId": 60147,
        "nodeName": "合同申请",
        "nodeStatus": "active",
        "assignee": "lisi",
        "assigneeName": "李四",
        "completeTime": null
      }
    ]
  }
}
```

### 空数据响应

```json
{
  "code": "001",
  "message": "项目不存在或无权限",
  "data": null
}
```

## 字段说明

### 项目基本信息（与项目列表单条数据一致）

| 字段 | 类型 | 说明 |
|------|------|------|
| id | integer | 项目唯一标识（主键） |
| sjId | string | 商机编号（如 P202605454450） |
| dyProjectName | string | 项目名称 |
| dyCustomerName | string | 客户名称 |
| dyProjectAmount | double | 项目总金额（含税） |
| dyProjectAmountReceived | double | 已收回金额 |
| dyProjectStage | string | 项目阶段 |
| dyProjectStatus | string | 项目状态（1=进行中，0=已终止） |
| dyProjectLeader | string | 项目负责人工号 |
| dyCreateTime | string | 创建时间（格式：YYYY-MM-DD HH:mm:ss） |
| dyUpdateTime | string | 更新时间 |
| deployId | string | 流程部署 ID（用于查询 BPMN 流程） |
| instanceId | string | 流程实例 ID |

### nodeList 节点列表（完整流转链路）

| 字段 | 类型 | 说明 |
|------|------|------|
| nodeId | integer | 节点 ID |
| nodeName | string | 节点名称 |
| nodeStatus | string | 节点状态（completed=已完成, active=进行中, pending=待处理） |
| assignee | string | 当前处理人工号 |
| assigneeName | string | 当前处理人姓名 |
| completeTime | string | 完成时间（未完成时为 null） |

## 使用注意事项

### ⚠️ 常见错误

1. **项目 ID 无效**
   - `id` 必须来自项目列表接口返回的 `id` 字段（整数主键）
   - 不要使用商机编号（sjId）

2. **权限不足**
   - 返回错误码非 `000` 时，可能是用户无权查看该项目详情
   - 确认 `iv-user` 为项目负责人或项目成员

3. **nodeList 可能部分字段缺失**
   - 未到达的节点可能缺少 assignee 信息
   - 已完成的节点 completeTime 不为 null

### ✅ 最佳实践

1. **结合项目列表使用**
   ```python
   # 从项目列表获取 id
   projects = get_project_list(flowType="1")
   for p in projects[:5]:
       detail = get_project_detail(p["id"])
       print(f"{p['dyProjectName']}: {len(detail['nodeList'])} 个节点")
   ```

2. **解析节点状态**
   ```python
   for node in detail.get("nodeList", []):
       status_icon = "✅" if node["nodeStatus"] == "completed" else "🔄"
       print(f"{status_icon} {node['nodeName']} - {node.get('assigneeName', '待分配')}")
   ```

3. **获取当前活跃节点**
   ```python
   active_nodes = [n for n in detail.get("nodeList", []) if n["nodeStatus"] == "active"]
   if active_nodes:
       current_node = active_nodes[0]
       print(f"当前节点: {current_node['nodeName']}, 处理人: {current_node['assigneeName']}")
   ```

## 相关 API

- **项目列表**: `POST /dy/project/list` - 查询项目列表获取 `id`
- **项目待办列表**: `GET /dy/project/getProjectTodoList?id={projectId}` - 查询项目待办任务
- **FlowAssistant 项目列表**: `POST /dy/project/flowAssistantProjectList` - 一并返回项目及待办
- **BPMN 流程定义**: `GET /dy/flowable/definition/readXml/{deployId}` - 获取流程定义 XML
- **流程流转记录**: `GET /dy/flowable/task/flowRecord` - 查询完整审批链路

## 版本历史

- **2026-06-10**: 初始版本，记录项目详情 API 使用规范

---

**最后更新**: 2026-06-10
**维护者**: DST 团队
**适用场景**: 项目详情查询、流程节点分析、当前进度追踪
