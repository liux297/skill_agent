# BPMN XML 解析脚本

## 概述

`parse_bpmn_xml.py` 是用于从 BPMN 定义接口获取 XML 文件，并解析为结构化 Markdown 文档的工具脚本。

## 功能特性

### 1. 自动获取和缓存
- 从 API 获取 BPMN XML 文件（需指定 deploy-id）
- 自动检查缓存有效性（按天校验，当天创建的视为有效）
- 缓存命中时直接返回，无需重复解析

### 2. 完整的 XML 解析

解析以下 BPMN 元素：
- **流程定义**：ID、名称、版本、描述
- **用户任务**：节点 ID、名称、分支条件说明
- **服务任务**：节点 ID、名称、实现方式
- **网关节点**：排他网关/包容网关/并行网关（自动推断语义化名称）
- **事件节点**：开始事件、结束事件、边界事件
- **关键流程连线**：仅展示有名称的连线（如"用印""不用印"等虚线说明）

### 3. 优化输出

- **精简表格**：移除全为 N/A 的无效字段（处理人/候选用户/候选组/表单），只保留有意义的信息
- **分支条件说明**：每个任务节点附带进入连线和输出分支的语义描述
- **网关自动命名**：通过下游节点集合推断网关含义（如"合同申请 → 框架申请"）
- **连线独立章节**：仅展示有名称的关键流程连线，含来源/目标节点和触发条件

## 使用方法

### 基本用法

```bash
cd <skill 目录>/scripts
python3 parse_bpmn_xml.py --user <工号> --deploy-id <部署ID>
```

### 完整参数

```bash
python3 parse_bpmn_xml.py \
  --user dstest \
  --deploy-id 26667672 \
  --url http://10.0.21.38:8080/dy/flowable/definition/readXml \
  --cache-dir ./cache/bpmn_data
```

| 参数 | 必填 | 默认值 | 说明 |
|------|------|--------|------|
| `--user` | 是 | - | 用户工号 |
| `--deploy-id` | 是 | - | 流程部署 ID（直客业务固定为 `26667672`） |
| `--url` | 否 | `http://10.0.21.38:8080/dy/flowable/definition/readXml` | BPMN 定义 API 地址 |
| `--cache-dir` | 否 | `./cache/bpmn_data` | 缓存目录 |

### 作为模块使用

```python
from scripts.parse_bpmn_xml import BPMNParser

# 初始化（默认缓存目录: ./cache/bpmn_data）
parser = BPMNParser(cache_dir="./cache/bpmn_data")

# 检查缓存（当天有效）
if not parser.is_cache_valid("26667672"):
    # 获取 XML
    xml_content = parser.fetch_bpmn_xml(
        "http://10.0.21.38:8080/dy/flowable/definition/readXml",
        "dstest",
        "26667672"
    )
    
    # 解析并生成 Markdown
    parsed_data = parser.parse_bpmn_xml(xml_content)
    markdown = parser.generate_markdown(parsed_data)
    
    # 保存缓存
    md_path = parser.save_cache("26667672", markdown, parsed_data)
    print(f"保存至：{md_path}")
else:
    # 使用缓存
    cached = parser.get_cached("26667672")
    print(cached['markdown'])
```

## 输出示例

### Markdown 输出结构

```markdown
# BPMN 流程定义：LTC 直客流程

**流程 ID**: `26667672`
**可执行**: true
**版本**: v1.0

## 🚀 开始事件

## 👤 用户任务（92 个）

| 节点名称 | 分支条件说明 |
|----------|-------------|
| 商机录入 | → 合同申请 / → 框架申请 |

## 🚦 网关节点（5 个）

| 节点 ID | 推断名称 | 类型 |
|---------|----------|------|

## 🔗 关键流程连线（12 条）

| 连线名称 | 来源节点 | 目标节点 | 触发条件 |
|----------|----------|----------|----------|
| 用印 | ... | ... | ... |

## 🏁 结束事件（37 个）

## 📊 统计摘要
```

### JSON 输出

完整结构化数据保存为 `.json` 文件，便于程序处理。

## 缓存机制

### 缓存文件结构

```
./cache/bpmn_data/
├── {deployId}.md         # Markdown 格式（主输出）
├── {deployId}.json       # JSON 格式（完整数据）
└── {deployId}.meta.json  # 元数据（创建时间、更新时间）
```

### 元数据结构

```json
{
  "deploy_id": "26667672",
  "created_at": "2026-06-09T10:30:00",
  "updated_at": "2026-06-09T10:30:00",
  "md_file": "./cache/bpmn_data/26667672.md",
  "json_file": "./cache/bpmn_data/26667672.json"
}
```

### 缓存有效期

- 按天校验：`.meta.json` 中记录的 `created_at` 为当天则视为有效
- 非当天：自动重新获取并更新缓存

## 解析内容详细说明

### 用户任务表（精简版）
- 只保留 **节点名称** 和 **分支条件说明** 两列
- 移除了处理人/候选用户/候选组/表单等全 N/A 的列
- 分支条件说明包含进入该节点的有名称连线 + 从该节点出发的分支输出

### 网关节点
- 通过下游节点集合自动推断语义化名称
- 例如：下游是"合同申请"和"框架申请" → 名称推断为"合同申请 → 框架申请"

### 关键流程连线
- 仅展示 **有 name 属性** 的连线（即流程图中的虚线标注说明）
- 无名称的普通流转连线不显示，避免信息噪音

### 结束事件
- 按来源节点聚合显示
- 说明哪些节点完成后流程结束

## 注意事项

1. **XML 编码**：脚本使用 UTF-8 编码处理 XML
2. **命名空间**：正确处理 BPMN 2.0 命名空间
3. **错误处理**：捕获并报告解析错误
4. **依赖**：Python 标准库（xml.etree.ElementTree）+ requests
5. **网络请求**：自动跳过 SSL 验证（`verify=False`）
6. **deploy-id**：直客业务流程固定为 `26667672`，无需从其他接口获取

## 故障排查

1. **XML 解析失败**：检查 deploy-id 是否正确、网络连接是否正常
2. **缓存无效**：删除缓存目录下对应文件，重新调用脚本
3. **权限问题**：确保缓存目录有写入权限

## 参考

- [BPMN 2.0 规范](https://www.omg.org/spec/BPMN/2.0/)
- [Flowable BPMN XML 格式](http://flowable.org/userguide/)
- [技能文档：BPMN 流程定义获取](../references/bpmn-definition-api.md)
