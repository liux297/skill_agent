#!/usr/bin/env python3
"""
BPMN XML 解析脚本（简化版）

用于从本地或 API 获取 BPMN XML 文件，解析为结构化 Markdown 文档。
支持两种模式：
  1. 本地文件模式：直接读取本地 XML 文件
  2. API 模式：从 BPMN 定义接口获取（需指定 --user 和 --deploy-id）

依赖：Python 标准库 xml.etree.ElementTree + requests（API 模式）
"""

import sys
import json
import os
import argparse
from datetime import datetime, timezone, timedelta
from pathlib import Path

# 导入主解析模块（同目录下的 parse_bpmn_xml.py）
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from parse_bpmn_xml import BPMNParser


def main():
    """主函数：根据参数选择本地文件模式或 API 模式"""
    parser = argparse.ArgumentParser(
        description='BPMN XML 解析工具（简化版，支持本地文件和 API 两种模式）',
        epilog='示例:\n'
               '  # API 模式（推荐）\n'
               '  python3 parse_flow_xml.py --user dstest --deploy-id 26667672\n'
               '  # 本地文件模式\n'
               '  python3 parse_flow_xml.py --file ./data/flow-definition.xml\n'
               '  # 指定缓存目录\n'
               '  python3 parse_flow_xml.py --user dstest --deploy-id 26667672 --cache-dir ./cache/bpmn_data',
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    parser.add_argument('--file', type=str,
                        help='本地 XML 文件路径（使用本地文件模式时必填）')
    parser.add_argument('--url', default='http://10.0.21.38:8080/dy/flowable/definition/readXml',
                        help='API 地址（默认使用 BPMN 定义接口）')
    parser.add_argument('--user', type=str,
                        help='用户工号（API 模式必填）')
    parser.add_argument('--deploy-id', type=str,
                        help='流程部署 ID（API 模式必填，直客业务固定为 26667672）')
    parser.add_argument('--cache-dir', type=str, default='./cache/bpmn_data',
                        help='缓存目录（默认: ./cache/bpmn_data）')
    parser.add_argument('--output', type=str,
                        help='输出文件路径（默认自动生成到缓存目录）')
    args = parser.parse_args()

    # 初始化解析器
    bpmn_parser = BPMNParser(cache_dir=args.cache_dir)

    # 模式选择
    if args.file:
        # ====== 本地文件模式 ======
        if not os.path.exists(args.file):
            print(f"❌ 文件不存在: {args.file}")
            sys.exit(1)

        print(f"📂 读取本地文件: {args.file}")
        with open(args.file, 'r', encoding='utf-8') as f:
            xml_content = f.read()

        if not xml_content.strip():
            print("⚠️ 文件内容为空")
            sys.exit(1)

    elif args.user and args.deploy_id:
        # ====== API 模式 ======
        deploy_id = args.deploy_id

        # 检查缓存
        if bpmn_parser.is_cache_valid(deploy_id):
            cached = bpmn_parser.get_cached(deploy_id)
            print(f"✅ 使用缓存文件: {cached['md_file']}")
            return

        # 获取 XML
        base_url = args.url.rstrip('/')
        print(f"📥 获取 BPMN XML: {base_url}/{deploy_id}")
        try:
            xml_content = bpmn_parser.fetch_bpmn_xml(base_url, args.user, deploy_id)
            print(f"✅ XML 获取成功，长度: {len(xml_content)} 字符")
        except Exception as e:
            print(f"❌ XML 获取失败: {e}")
            sys.exit(1)

    else:
        parser.print_help()
        print("\n❌ 错误: 必须指定 --file（本地模式）或同时指定 --user 和 --deploy-id（API 模式）")
        sys.exit(1)

    # 解析 XML
    try:
        parsed_data = bpmn_parser.parse_bpmn_xml(xml_content)
        print(f"✅ 解析完成")
    except Exception as e:
        print(f"⚠️ XML 解析失败: {e}")
        print("⚠️ 自动回退到原始 XML 格式（兼容旧逻辑）")
        print("\n--- BPMN XML 原始内容 ---\n")
        print(xml_content[:2000] if len(xml_content) > 2000 else xml_content)
        print("\n--- 原始内容结束 ---\n")
        sys.exit(1)

    # 生成 Markdown
    markdown = bpmn_parser.generate_markdown(parsed_data)

    # 输出结果
    if args.output:
        output_path = Path(args.output)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(markdown)
        print(f"\n📄 输出文件: {output_path}")
    elif args.user and args.deploy_id:
        # API 模式：保存到缓存
        md_path = bpmn_parser.save_cache(args.deploy_id, markdown, parsed_data)
        print(f"\n📄 缓存保存至: {md_path}")
    else:
        # 本地文件模式无指定输出：直接打印到控制台
        print("\n" + markdown)


if __name__ == "__main__":
    main()
