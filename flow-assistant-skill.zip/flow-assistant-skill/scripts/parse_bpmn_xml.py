#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
BPMN XML 解析为 Markdown 工具

从 API 获取 BPMN XML，解析为结构化 Markdown 文档，便于 LLM 理解
"""

import requests
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta
from pathlib import Path
import json
import os


class BPMNParser:
    """BPMN XML 解析器"""
    
    def __init__(self, cache_dir: str = "./cache/bpmn_data"):
        """初始化解析器"""
        self.cache_dir = Path(cache_dir)
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        
    def fetch_bpmn_xml(self, url: str, user_id: str, deploy_id: str) -> str:
        """从 API 获取 BPMN XML"""
        headers = {
            'Accept': '*/*',
            'iv-user': user_id,
            'systemcode': 'AGENT'
        }
        
        response = requests.get(
            f"{url}/{deploy_id}",
            headers=headers,
            verify=False
        )
        response.raise_for_status()
        
        # API 返回的是 JSON 格式，XML 在 data 字段中
        try:
            json_response = response.json()
            if json_response.get('code') == '000':
                return json_response.get('data', '')
            else:
                raise ValueError(f"API 返回错误：{json_response.get('message', 'Unknown error')}")
        except Exception as e:
            # 如果不是 JSON，直接返回原始文本
            print(f"⚠️  响应不是 JSON，返回原始文本：{e}")
            return response.text
    
    def parse_bpmn_xml(self, xml_content: str) -> dict:
        """解析 BPMN XML 为结构化数据"""
        root = ET.fromstring(xml_content)
        
        # 定义命名空间
        ns = {
            'bpmn2': 'http://www.omg.org/spec/BPMN/20100524/MODEL',
            'dc': 'http://www.omg.org/spec/DD/20100524/DC',
            'di': 'http://www.omg.org/spec/DD/20100524/DI'
        }
        
        result = {
            'process_definition': {},
            'flows': [],
            'tasks': [],
            'gateways': [],
            'events': []
        }
        
        # 提取流程定义信息
        process = root.find('.//bpmn2:process', ns)
        if process is not None:
            # 获取流程描述
            process_desc = process.find('bpmn2:description', ns)
            
            result['process_definition'] = {
                'id': process.get('id'),
                'name': process.get('name') or 'Unknown',
                'executable': process.get('executable'),
                'description': process_desc.text if process_desc is not None else None,
                'version': process.get('version')
            }
        
        # 提取所有节点
        for element in root.iter():
            tag = element.tag.split('}')[-1]  # 移除命名空间前缀
            
            # 获取节点描述
            description = element.find('bpmn2:description', ns)
            description_text = description.text if description is not None else None
            
            # 获取节点标签
            label = element.find('.//bpmn2:label', ns)
            label_text = label.text if label is not None else None
            
            # 如果有标签，且描述为空，则使用标签作为描述
            if label_text and not description_text:
                description_text = label_text
            
            if tag == 'userTask':  # 用户任务节点
                # 获取表单信息
                form_properties = self._extract_form_properties(element)
                
                task = {
                    'id': element.get('id'),
                    'name': element.get('name') or '未命名',
                    'type': 'UserTask',
                    'category': element.get('category'),
                    'description': description_text,
                    'assignee': self._find_property(element, 'assignee'),
                    'candidate_users': self._find_property(element, 'candidateUsers'),
                    'candidate_groups': self._find_property(element, 'candidateGroups'),
                    'form_key': form_properties.get('form_key'),
                    'form_type': form_properties.get('form_type'),
                    'properties': form_properties.get('properties', {})
                }
                result['tasks'].append(task)
                
            elif tag == 'serviceTask':  # 服务任务节点
                task = {
                    'id': element.get('id'),
                    'name': element.get('name') or '未命名',
                    'type': 'ServiceTask',
                    'implementation': element.get('implementation'),
                    'description': description_text,
                    'class': element.get('class'),
                    'delegate_expression': element.get('delegateExpression')
                }
                result['tasks'].append(task)
                
            elif tag == 'exclusiveGateway':  # 排他网关
                gateway = {
                    'id': element.get('id'),
                    'name': element.get('name') or '未命名',
                    'type': 'ExclusiveGateway',
                    'description': description_text,
                    'default': element.get('default')
                }
                result['gateways'].append(gateway)
                
            elif tag == 'inclusiveGateway':  # 包容网关
                gateway = {
                    'id': element.get('id'),
                    'name': element.get('name') or '未命名',
                    'type': 'InclusiveGateway',
                    'description': description_text
                }
                result['gateways'].append(gateway)
                
            elif tag == 'parallelGateway':  # 并行网关
                gateway = {
                    'id': element.get('id'),
                    'name': element.get('name') or '未命名',
                    'type': 'ParallelGateway',
                    'description': description_text
                }
                result['gateways'].append(gateway)
                
            elif tag == 'startEvent':  # 开始事件
                # 获取开始事件的触发条件
                data_objects = self._find_data_objects(element, ns)
                event = {
                    'id': element.get('id'),
                    'name': element.get('name') or '开始',
                    'type': 'StartEvent',
                    'description': description_text,
                    'initiator': element.get('initiator'),
                    'data_objects': data_objects
                }
                result['events'].append(event)
                
            elif tag == 'endEvent':  # 结束事件
                # 获取结束事件的终止原因
                data_objects = self._find_data_objects(element, ns)
                event = {
                    'id': element.get('id'),
                    'name': element.get('name') or '结束',
                    'type': 'EndEvent',
                    'description': description_text,
                    'data_objects': data_objects
                }
                result['events'].append(event)
                
            elif tag == 'intermediateThrowEvent':  # 中间事件
                # 检查是定时器还是消息事件
                timer_event = element.find('bpmn2:timerEventDefinition', ns)
                message_event = element.find('bpmn2:messageEventDefinition', ns)
                
                event = {
                    'id': element.get('id'),
                    'name': element.get('name') or '中间事件',
                    'type': 'IntermediateThrowEvent',
                    'description': description_text,
                    'event_type': 'timer' if timer_event is not None else 'message' if message_event is not None else 'unknown'
                }
                result['events'].append(event)
                
            elif tag == 'boundaryEvent':  # 边界事件
                event = {
                    'id': element.get('id'),
                    'name': element.get('name') or '边界事件',
                    'type': 'BoundaryEvent',
                    'description': description_text,
                    'cancelActivity': element.get('cancelActivity', 'true'),
                    'attachedToRef': element.get('attachedToRef')
                }
                result['events'].append(event)
        
        # 提取所有流程连线
        for element in root.iter():
            tag = element.tag.split('}')[-1]
            
            if tag == 'sequenceFlow':  # 流程连线
                flow = {
                    'id': element.get('id'),
                    'sourceRef': element.get('sourceRef'),
                    'targetRef': element.get('targetRef'),
                    'name': element.get('name') or '未命名',
                    'conditionExpression': self._find_condition(element, ns)
                }
                result['flows'].append(flow)
        
        return result
    
    def _find_property(self, element: ET.Element, prop_name: str) -> list:
        """查找扩展属性"""
        properties = []
        extension_elements = element.findall('bpmn2:extensionElements', 
                                              {'bpmn2': 'http://www.omg.org/spec/BPMN/20100524/MODEL'})
        for ext in extension_elements:
            property_element = ext.find(f'bpmn2:{prop_name}', 
                                        {'bpmn2': 'http://www.omg.org/spec/BPMN/20100524/MODEL'})
            if property_element is not None:
                properties.append(property_element.get('value'))
        return properties if properties else None
    
    def _extract_form_properties(self, element: ET.Element) -> dict:
        """提取表单相关属性"""
        props = {
            'form_key': None,
            'form_type': None,
            'properties': {}
        }
        
        extension_elements = element.findall('bpmn2:extensionElements', 
                                              {'bpmn2': 'http://www.omg.org/spec/BPMN/20100524/MODEL'})
        for ext in extension_elements:
            # 查找 formKey
            form_key = ext.find('bpmn2:formKey', 
                               {'bpmn2': 'http://www.omg.org/spec/BPMN/20100524/MODEL'})
            if form_key is not None:
                props['form_key'] = form_key.get('value')
                props['form_type'] = form_key.get('type') or 'form'
            
            # 查找扩展属性
            props_elements = ext.findall('bpmn2:properties', 
                                         {'bpmn2': 'http://www.omg.org/spec/BPMN/20100524/MODEL'})
            for prop in props_elements:
                for property_element in prop.findall('bpmn2:property', 
                                                      {'bpmn2': 'http://www.omg.org/spec/BPMN/20100524/MODEL'}):
                    prop_name = property_element.get('name')
                    prop_value = property_element.get('value')
                    if prop_name and prop_value:
                        props['properties'][prop_name] = prop_value
        
        return props
    
    def _find_data_objects(self, element: ET.Element, ns: dict) -> list:
        """查找数据对象关联"""
        data_objects = []
        
        # 查找 dataInputAssociation 和 dataOutputAssociation
        for assoc_type in ['dataInputAssociation', 'dataOutputAssociation']:
            assoc_elements = element.findall(f'bpmn2:{assoc_type}', ns)
            for assoc in assoc_elements:
                source_ref = assoc.get('sourceRef')
                target_ref = assoc.get('targetRef')
                if source_ref or target_ref:
                    data_objects.append({
                        'source': source_ref,
                        'target': target_ref
                    })
        
        return data_objects if data_objects else []
    
    def _find_condition(self, element: ET.Element, ns: dict) -> str:
        """查找条件表达式"""
        condition = element.find('bpmn2:conditionExpression', ns)
        if condition is not None:
            return condition.text
        return None
    
    def _build_task_id_to_name(self, parsed_data: dict) -> dict:
        """构建节点ID到名称的映射"""
        id_to_name = {}
        for task in parsed_data.get('tasks', []):
            id_to_name[task['id']] = task['name']
        for gw in parsed_data.get('gateways', []):
            id_to_name[gw['id']] = gw['name']
        for event in parsed_data.get('events', []):
            id_to_name[event['id']] = event['name']
        return id_to_name
    
    def _get_meaningful_flows(self, parsed_data: dict, id_to_name: dict) -> dict:
        """提取有名称的流程连线，按目标节点分组，用于补充节点说明"""
        target_flows = {}
        for flow in parsed_data.get('flows', []):
            target = flow['targetRef']
            name = flow.get('name', '未命名')
            condition = flow.get('conditionExpression')
            source = flow['sourceRef']
            
            # 跳过自循环和"未命名"的连线
            if source == target or name == '未命名':
                continue
            
            if target not in target_flows:
                target_flows[target] = []
            
            source_name = id_to_name.get(source, source)
            desc_parts = [name]
            if condition:
                desc_parts.append(f"({condition})")
            target_flows[target].append({'name': name, 'from': source_name, 'condition': condition})
        
        return target_flows
    
    def _build_flow_graph(self, parsed_data: dict) -> dict:
        """构建节点到下游节点的映射，用于命名网关"""
        downstream = {}
        id_to_name = self._build_task_id_to_name(parsed_data)
        for flow in parsed_data.get('flows', []):
            src = flow['sourceRef']
            tgt = flow['targetRef']
            if src != tgt:  # 排除自循环
                if src not in downstream:
                    downstream[src] = []
                tgt_name = id_to_name.get(tgt, tgt)
                flow_name = flow.get('name', '')
                downstream[src].append({'id': tgt, 'name': tgt_name, 'flow_name': flow_name})
        return downstream
    
    def generate_markdown(self, parsed_data: dict) -> str:
        """生成 Markdown 文档（优化版：精简字段、补充连线说明、移除无效信息）"""
        md = []
        
        # 构建辅助数据
        id_to_name = self._build_task_id_to_name(parsed_data)
        target_flows = self._get_meaningful_flows(parsed_data, id_to_name)
        flow_graph = self._build_flow_graph(parsed_data)
        
        # 标题
        proc_def = parsed_data['process_definition']
        md.append(f"# BPMN 流程定义：{proc_def.get('name', '未知流程')}")
        md.append("")
        md.append(f"- 流程 ID: `{proc_def.get('id')}`")
        if proc_def.get('description'):
            md.append(f"- 描述: {proc_def['description']}")
        md.append("")
        md.append("> 此文档由 BPMN XML 自动解析生成，反映系统最新流程定义。")
        md.append("")
        
        # 开始事件
        starts = [e for e in parsed_data.get('events', []) if e['type'] == 'StartEvent']
        if starts:
            md.append("## 🚀 开始事件")
            md.append("")
            for event in starts:
                md.append(f"- **{event['name']}** (`{event['id']}`)")
                if event.get('description'):
                    md.append(f"  - {event['description']}")
            md.append("")
        
        # ===== 主流程描述（按流程图顺序组织） =====
        md.append("## 📋 流程节点清单")
        md.append("")
        
        # 从开始事件出发，BFS 遍历主流程路径
        start_id = starts[0]['id'] if starts else None
        
        # 1) 用户任务（只保留有意义的列：节点ID、节点名称、分支说明）
        user_tasks = [t for t in parsed_data.get('tasks', []) if t['type'] == 'UserTask']
        if user_tasks:
            md.append("### 👤 用户任务节点")
            md.append("")
            md.append("| # | 节点名称 | 分支条件说明 |")
            md.append("|---|----------|-------------|")
            
            # 按名称排序以便阅读
            sorted_tasks = sorted(user_tasks, key=lambda t: t['name'])
            for i, task in enumerate(sorted_tasks, 1):
                desc_parts = []
                
                # 收集进入该节点的有意义连线说明
                flows_in = target_flows.get(task['id'], [])
                for fi in flows_in:
                    desc_parts.append(f"{fi['name']}（来自「{fi['from']}」）")
                
                # 收集从该节点出发的有意义连线说明（分支输出）
                out_flows = flow_graph.get(task['id'], [])
                out_names = [f['flow_name'] for f in out_flows if f['flow_name'] and f['flow_name'] != '未命名']
                if out_names:
                    desc_parts.append(f"完成后可走：{' / '.join(sorted(set(out_names)))}")
                
                description = "；".join(desc_parts) if desc_parts else "-"
                # 转义 markdown 特殊字符
                description = description.replace('|', '\\|')
                md.append(f"| {i} | {task['name']} | {description} |")
            md.append("")
        
        # 2) 服务任务
        service_tasks = [t for t in parsed_data.get('tasks', []) if t['type'] == 'ServiceTask']
        if service_tasks:
            md.append("### ⚙️ 服务任务")
            md.append("")
            for task in service_tasks:
                md.append(f"- **{task['name']}** (`{task['id']}`)")
                if task.get('implementation'):
                    md.append(f"  - 实现: {task['implementation']}")
            md.append("")
        
        # 3) 网关（推断名称：用下游节点名描述）
        gateways = parsed_data.get('gateways', [])
        if gateways:
            md.append("### 🚦 分支网关")
            md.append("")
            for gw in gateways:
                # 推断网关含义：看下游节点集合
                downstream_nodes = flow_graph.get(gw['id'], [])
                d_names = [d['name'] for d in downstream_nodes if d['name'] != '未命名']
                name_hint = " → ".join(d_names[:3]) if d_names else "分支节点"
                if len(d_names) > 3:
                    name_hint += f" ...（共{len(d_names)}个分支）"
                md.append(f"- **{name_hint}** (`{gw['id']}`, {gw['type']})")
                
                # 列出各分支
                for d in downstream_nodes:
                    label = d['flow_name'] if d['flow_name'] and d['flow_name'] != '未命名' else "→"
                    md.append(f"  - {label} 「{d['name']}」(`{d['id']}`)")
            md.append("")
        
        # 4) 流程连线（仅显示有名称的，即虚线说明）
        named_flows = [f for f in parsed_data.get('flows', [])
                       if f['sourceRef'] != f['targetRef']  # 排除自循环
                       and f.get('name') and f['name'] != '未命名']
        if named_flows:
            md.append("### 🔀 关键流程连线（虚线说明）")
            md.append("")
            md.append("| 连线说明 | 来源节点 | 目标节点 | 触发条件 |")
            md.append("|----------|----------|----------|----------|")
            for flow in named_flows:
                src_name = id_to_name.get(flow['sourceRef'], flow['sourceRef'])
                tgt_name = id_to_name.get(flow['targetRef'], flow['targetRef'])
                condition = flow.get('conditionExpression') or "-"
                md.append(f"| {flow['name']} | {src_name} | {tgt_name} | `{condition}` |")
            md.append("")
        
        # 5) 结束事件（聚合显示，说明流程终止位置）
        ends = [e for e in parsed_data.get('events', []) if e['type'] == 'EndEvent']
        if ends:
            md.append(f"### 🏁 结束事件（共 {len(ends)} 个）")
            md.append("")
            md.append("以下节点完成后流程结束：")
            md.append("")
            # 找出哪些节点直接连到结束事件
            end_sources = {}
            for flow in parsed_data.get('flows', []):
                for end in ends:
                    if flow['targetRef'] == end['id'] and flow['sourceRef'] != end['id']:
                        src_name = id_to_name.get(flow['sourceRef'], flow['sourceRef'])
                        end_sources[flow['sourceRef']] = src_name
            
            for src_id, src_name in sorted(set(end_sources.items()), key=lambda x: x[1]):
                condition = ""
                for flow in parsed_data.get('flows', []):
                    if flow['sourceRef'] == src_id and flow['targetRef'] in [e['id'] for e in ends]:
                        cond = flow.get('conditionExpression')
                        if cond:
                            condition = f"（条件: `{cond}`）"
                            break
                md.append(f"- 「{src_name}」完成后 {condition}")
            md.append("")
        
        # 6) 其他事件（中间事件、边界事件等）
        intermediate = [e for e in parsed_data.get('events', []) if e['type'] == 'IntermediateThrowEvent']
        if intermediate:
            md.append("### ⏱️ 中间事件")
            md.append("")
            for event in intermediate:
                md.append(f"- **{event['name']}** (`{event['id']}`, {event['event_type']})")
            md.append("")
        
        boundaries = [e for e in parsed_data.get('events', []) if e['type'] == 'BoundaryEvent']
        if boundaries:
            md.append("### ⚠️ 边界事件")
            md.append("")
            for event in boundaries:
                md.append(f"- **{event['name']}** (`{event['id']}`) → 附加于 `{event.get('attachedToRef', '?')}`")
            md.append("")
        
        return "\n".join(md)
    
    def save_cache(self, deploy_id: str, markdown: str, parsed_data: dict) -> str:
        """缓存解析结果"""
        # 保存 Markdown 版本
        md_path = self.cache_dir / f"{deploy_id}.md"
        md_path.write_text(markdown, encoding='utf-8')

        # 保存 JSON 版本（完整数据）
        json_path = self.cache_dir / f"{deploy_id}.json"
        json_path.write_text(json.dumps(parsed_data, ensure_ascii=False, indent=2), encoding='utf-8')

        # 保存元数据（更新时间）
        meta_path = self.cache_dir / f"{deploy_id}.meta.json"
        meta_data = {
            'deploy_id': deploy_id,
            'created_at': datetime.now().isoformat(),
            'updated_at': datetime.now().isoformat(),
            'md_file': str(md_path),
            'json_file': str(json_path)
        }
        meta_path.write_text(json.dumps(meta_data, ensure_ascii=False, indent=2), encoding='utf-8')
        
        return str(md_path)
    
    def is_cache_valid(self, deploy_id: str) -> bool:
        """检查缓存是否有效（基于创建时间是否为同一天）"""
        meta_path = self.cache_dir / f"{deploy_id}.meta.json"
        
        if not meta_path.exists():
            return False
        
        try:
            meta_data = json.loads(meta_path.read_text(encoding='utf-8'))
            created_at = datetime.fromisoformat(meta_data['created_at'])
            today = datetime.now().date()
            created_date = created_at.date()
            
            # 检查创建时间是否为当天
            is_today = created_date == today
            if not is_today:
                print(f"⚠️  缓存文件创建于 {created_date}，不是当天，需要更新")
            
            return is_today
        except Exception as e:
            print(f"⚠️  检查缓存时出错：{e}")
            return False
    
    def get_cached(self, deploy_id: str) -> dict:
        """获取缓存的解析结果"""
        md_path = self.cache_dir / f"{deploy_id}.md"
        json_path = self.cache_dir / f"{deploy_id}.json"
        
        if not md_path.exists() or not json_path.exists():
            return None
        
        return {
            'markdown': md_path.read_text(encoding='utf-8'),
            'json': json.loads(json_path.read_text(encoding='utf-8')),
            'md_file': str(md_path),
            'json_file': str(json_path)
        }


def main():
    """主函数"""
    # 使用 argparse 接收命令行参数
    import argparse
    parser = argparse.ArgumentParser(description='BPMN XML 解析工具')
    parser.add_argument('--url', default='http://10.0.21.38:8080/dy/flowable/definition/readXml', help='API 地址')
    parser.add_argument('--user', required=True, help='用户工号')
    parser.add_argument('--deploy-id', required=True, help='流程部署 ID')
    args = parser.parse_args()

    BASE_URL = args.url
    USER_ID = args.user
    DEPLOY_ID = args.deploy_id

    bpmn_parser = BPMNParser()
    
    try:
        # 检查缓存
        if bpmn_parser.is_cache_valid(DEPLOY_ID):
            cached = bpmn_parser.get_cached(DEPLOY_ID)
            print(f"✅ 使用缓存文件：{cached['md_file']}")
            return
        
        # 获取 XML
        print(f"📥 获取 BPMN XML: {BASE_URL}/{DEPLOY_ID}")
        xml_content = bpmn_parser.fetch_bpmn_xml(BASE_URL, USER_ID, DEPLOY_ID)
        print(f"✅ XML 获取成功，长度：{len(xml_content)} 字符")
        
        # 解析 XML
        print("🔄 解析 XML...")
        parsed_data = bpmn_parser.parse_bpmn_xml(xml_content)
        
        # 生成 Markdown
        print("📝 生成 Markdown...")
        markdown = bpmn_parser.generate_markdown(parsed_data)
        
        # 保存缓存
        md_path = bpmn_parser.save_cache(DEPLOY_ID, markdown, parsed_data)
        print(f"✅ 解析完成，已保存至：{md_path}")
        
        # 输出摘要
        print(f"\n📊 解析结果摘要：")
        print(f"   - 流程名称：{parsed_data['process_definition'].get('name', '未知')}")
        print(f"   - 用户任务数：{len([t for t in parsed_data['tasks'] if t['type'] == 'UserTask'])}")
        print(f"   - 服务任务数：{len([t for t in parsed_data['tasks'] if t['type'] == 'ServiceTask'])}")
        print(f"   - 网关数：{len(parsed_data['gateways'])}")
        print(f"   - 流程连线数：{len(parsed_data['flows'])}")
        
    except Exception as e:
        print(f"❌ 错误：{e}")
        raise


if __name__ == "__main__":
    main()
