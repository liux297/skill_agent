#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
项目列表查询工具

调用项目列表 API，精简响应数据（只保留展示所需字段），避免响应过大被截断。
同时支持智能助手项目列表（含待办）。

用法：
  python3 query_project_list.py --iv-user dstest [--page-size 5] [--flow-type 2] [--with-todo]
  python3 query_project_list.py --iv-user dstest --search "关键词"
"""

import argparse
import json
import sys
import urllib.request
import urllib.error


BASE_URL = "http://10.0.21.38:8080"

# 项目列表保留字段
PROJECT_KEEP_FIELDS = (
    'id', 'dyProjectName', 'dyCustomerName', 'dyProjectAmount',
    'dyCreateTime', 'instanceId', 'creator', 'progressRate'
)

# 待办列表保留字段（仅 --with-todo 时使用）
TODO_KEEP_FIELDS = (
    'taskName', 'businessTitle', 'assigneeName', 'stayDays',
    'taskLink', 'actionUrl', 'extendParams'
)


def query_project_list(iv_user: str, page_size: int = 5, flow_type: str = "2",
                       search: str = "", with_todo: bool = False) -> dict:
    """查询项目列表并精简响应"""
    endpoint = "/dy/project/flowAssistantProjectList" if with_todo else "/dy/project/list"

    body = {
        "flowType": flow_type,
        "pageNum": 1,
        "pageSize": page_size,
        "projectTime": 0,
        "businessOpportunityInfo": search,
    }

    req = urllib.request.Request(
        f"{BASE_URL}{endpoint}",
        data=json.dumps(body).encode("utf-8"),
        headers={
            "Content-Type": "application/json",
            "iv-user": iv_user,
        },
        method="POST",
    )

    try:
        with urllib.request.urlopen(req) as resp:
            data = json.loads(resp.read().decode("utf-8"))
    except urllib.error.URLError as e:
        return {"code": "ERR", "message": f"API 请求失败: {e}"}

    if data.get("code") != "000":
        return data

    # 精简项目字段
    result = data.get("data", {}).get("result", [])
    for p in result:
        for k in list(p.keys()):
            if k not in PROJECT_KEEP_FIELDS:
                del p[k]

        # 精简待办字段（仅智能助手接口）
        if with_todo:
            for t in p.get("todoList", []):
                for k in list(t.keys()):
                    if k not in TODO_KEEP_FIELDS:
                        del t[k]

    return data


def main():
    parser = argparse.ArgumentParser(description="项目列表查询工具")
    parser.add_argument("--iv-user", required=True, help="用户工号")
    parser.add_argument("--page-size", type=int, default=5, help="每页条数（默认5）")
    parser.add_argument("--flow-type", default="2", help="流程类型（默认2=我参与的）")
    parser.add_argument("--search", default="", help="商机名称/编号/项目名称（模糊搜索）")
    parser.add_argument("--with-todo", action="store_true", help="使用智能助手接口（含待办）")
    args = parser.parse_args()

    result = query_project_list(
        iv_user=args.iv_user,
        page_size=args.page_size,
        flow_type=args.flow_type,
        search=args.search,
        with_todo=args.with_todo,
    )

    print(json.dumps(result, ensure_ascii=False))


if __name__ == "__main__":
    main()
